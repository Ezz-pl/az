import { Router } from "express";
import { z } from "zod";
import { db } from "../db";
import { reviews, reviewStats, reviewResponses, eq, desc, and, sql, count, avg } from "../db/schema";

const router = Router();

// إنشاء تقييم جديد
router.post("/", async (req, res) => {
  try {
    const reviewData = req.body;
    
    // التحقق من صحة البيانات
    if (!reviewData.serviceType || !reviewData.serviceId || !reviewData.customerName || !reviewData.rating) {
      return res.status(400).json({ error: "معلومات التقييم غير مكتملة" });
    }

    // إنشاء التقييم
    const [newReview] = await db
      .insert(reviews)
      .values({
        serviceType: reviewData.serviceType,
        serviceId: reviewData.serviceId,
        partnerId: reviewData.partnerId,
        bookingId: reviewData.bookingId,
        customerName: reviewData.customerName,
        customerEmail: reviewData.customerEmail,
        rating: reviewData.rating.toString(),
        title: reviewData.title,
        comment: reviewData.comment,
        pros: reviewData.pros || [],
        cons: reviewData.cons || [],
        verified: false,
        status: "pending"
      })
      .returning();

    // تحديث إحصائيات التقييمات
    await updateReviewStatsForService(reviewData.serviceType, reviewData.serviceId);

    res.json(newReview);
  } catch (error) {
    console.error("خطأ في إنشاء التقييم:", error);
    res.status(500).json({ error: "حدث خطأ أثناء إنشاء التقييم" });
  }
});

// جلب التقييمات لخدمة معينة
router.get("/:serviceType/:serviceId", async (req, res) => {
  try {
    const { serviceType, serviceId } = req.params;
    
    const serviceReviews = await db
      .select({
        id: reviews.id,
        customerName: reviews.customerName,
        rating: reviews.rating,
        title: reviews.title,
        comment: reviews.comment,
        pros: reviews.pros,
        cons: reviews.cons,
        images: reviews.images,
        verified: reviews.verified,
        helpful: reviews.helpful,
        createdAt: reviews.createdAt,
        response: {
          response: reviewResponses.response,
          respondedBy: reviewResponses.respondedBy,
          createdAt: reviewResponses.createdAt
        }
      })
      .from(reviews)
      .leftJoin(reviewResponses, eq(reviews.id, reviewResponses.reviewId))
      .where(
        and(
          eq(reviews.serviceType, serviceType),
          eq(reviews.serviceId, parseInt(serviceId)),
          eq(reviews.status, "approved")
        )
      )
      .orderBy(desc(reviews.createdAt));

    res.json(serviceReviews);
  } catch (error) {
    console.error("خطأ في جلب التقييمات:", error);
    res.status(500).json({ error: "حدث خطأ أثناء جلب التقييمات" });
  }
});

// جلب إحصائيات التقييمات
router.get("/:serviceType/:serviceId/stats", async (req, res) => {
  try {
    const { serviceType, serviceId } = req.params;
    
    const [stats] = await db
      .select()
      .from(reviewStats)
      .where(
        and(
          eq(reviewStats.serviceType, serviceType),
          eq(reviewStats.serviceId, parseInt(serviceId))
        )
      );

    if (!stats) {
      // إنشاء إحصائيات جديدة إذا لم تكن موجودة
      await updateReviewStatsForService(serviceType, parseInt(serviceId));
      
      const [newStats] = await db
        .select()
        .from(reviewStats)
        .where(
          and(
            eq(reviewStats.serviceType, serviceType),
            eq(reviewStats.serviceId, parseInt(serviceId))
          )
        );
      
      return res.json(newStats || {
        totalReviews: 0,
        averageRating: 0,
        ratingDistribution: {}
      });
    }

    // تحويل string إلى object للتوزيع
    const distribution = stats.ratingDistribution ? JSON.parse(stats.ratingDistribution) : {};

    res.json({
      totalReviews: stats.totalReviews,
      averageRating: parseFloat(stats.averageRating),
      ratingDistribution: distribution
    });
  } catch (error) {
    console.error("خطأ في جلب إحصائيات التقييمات:", error);
    res.status(500).json({ error: "حدث خطأ أثناء جلب الإحصائيات" });
  }
});

// إضافة رد على تقييم (للشركاء)
router.post("/:reviewId/response", async (req, res) => {
  try {
    const { reviewId } = req.params;
    const { response, partnerId, respondedBy } = req.body;

    if (!response || !partnerId) {
      return res.status(400).json({ error: "بيانات الرد غير مكتملة" });
    }

    const [newResponse] = await db
      .insert(reviewResponses)
      .values({
        reviewId: parseInt(reviewId),
        partnerId,
        response,
        respondedBy: respondedBy || "إدارة الشركة"
      })
      .returning();

    res.json(newResponse);
  } catch (error) {
    console.error("خطأ في إضافة الرد:", error);
    res.status(500).json({ error: "حدث خطأ أثناء إضافة الرد" });
  }
});

// تحديث إحصائيات التقييمات
async function updateReviewStatsForService(serviceType: string, serviceId: number) {
  try {
    // حساب المجموع والمتوسط
    const [aggregates] = await db
      .select({
        totalReviews: count(),
        averageRating: avg(reviews.rating)
      })
      .from(reviews)
      .where(
        and(
          eq(reviews.serviceType, serviceType),
          eq(reviews.serviceId, serviceId),
          eq(reviews.status, "approved")
        )
      );

    // حساب توزيع التقييمات
    const distributionQuery = await db
      .select({
        rating: sql`FLOOR(CAST(${reviews.rating} AS DECIMAL))`.as('rating'),
        count: count()
      })
      .from(reviews)
      .where(
        and(
          eq(reviews.serviceType, serviceType),
          eq(reviews.serviceId, serviceId),
          eq(reviews.status, "approved")
        )
      )
      .groupBy(sql`FLOOR(CAST(${reviews.rating} AS DECIMAL))`);

    // تحويل النتائج إلى object
    const distribution: Record<string, number> = {};
    distributionQuery.forEach(row => {
      distribution[row.rating.toString()] = row.count;
    });

    // إدراج أو تحديث الإحصائيات
    await db
      .insert(reviewStats)
      .values({
        serviceType,
        serviceId,
        totalReviews: aggregates.totalReviews || 0,
        averageRating: aggregates.averageRating?.toString() || "0.00",
        ratingDistribution: JSON.stringify(distribution),
        lastUpdated: new Date()
      })
      .onConflictDoUpdate({
        target: [reviewStats.serviceType, reviewStats.serviceId],
        set: {
          totalReviews: aggregates.totalReviews || 0,
          averageRating: aggregates.averageRating?.toString() || "0.00",
          ratingDistribution: JSON.stringify(distribution),
          lastUpdated: new Date()
        }
      });

  } catch (error) {
    console.error("خطأ في تحديث إحصائيات التقييمات:", error);
  }
}

export default router;