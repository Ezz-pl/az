-- تنظيف جميع البيانات التجريبية
DELETE FROM bookings;
DELETE FROM vehicles;
DELETE FROM categories;

-- إضافة التصنيفات الأساسية فقط
INSERT INTO categories (name, name_ar, description, description_ar, icon, slug, color) VALUES
('Desert Adventures', 'مغامرات البر', 'Desert camping and off-road adventures', 'مخيمات البر ومغامرات الطرق الوعرة', 'tent', 'desert_adventures', '#D97706'),
('Marine Adventures', 'المغامرات البحرية', 'Boats, yachts and water sports', 'القوارب واليخوت والرياضات المائية', 'anchor', 'marine_adventures', '#0369A1'),
('ATV Adventures', 'مغامرات الدبابات', 'ATVs, quads and off-road vehicles', 'الدبابات والكوادز والمركبات الوعرة', 'zap', 'atv_adventures', '#DC2626');