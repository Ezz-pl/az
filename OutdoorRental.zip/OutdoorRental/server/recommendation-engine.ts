import { db } from "./db";
import { 
  vehicles, 
  searchHistory, 
  userInteractions, 
  recommendations, 
  categories,
  regions,
  bookings,
  type Recommendation 
} from "@shared/schema";
import { eq, desc, sql, and, or, gte, lte, ne, inArray } from "drizzle-orm";

export interface RecommendationInput {
  sessionId: string;
  customerId?: number;
  currentVehicleId?: number;
  searchQuery?: string;
  categoryId?: number;
  regionId?: number;
  priceRange?: { min: number; max: number };
  limit?: number;
}

export interface RecommendationResult {
  vehicleId: number;
  score: number;
  type: string;
  reason: string;
  metadata: any;
}

export class RecommendationEngine {
  
  /**
   * توليد التوصيات الذكية بناءً على سلوك المستخدم
   */
  async generateRecommendations(input: RecommendationInput): Promise<RecommendationResult[]> {
    const recommendations: RecommendationResult[] = [];
    
    // الحصول على التوصيات من مصادر مختلفة
    const similarVehicles = await this.getSimilarVehicles(input);
    const trendingVehicles = await this.getTrendingVehicles(input);
    const personalizedRecs = await this.getPersonalizedRecommendations(input);
    const popularInCategory = await this.getPopularInCategory(input);
    
    // دمج وترتيب التوصيات
    recommendations.push(...similarVehicles);
    recommendations.push(...trendingVehicles);
    recommendations.push(...personalizedRecs);
    recommendations.push(...popularInCategory);
    
    // ترتيب حسب النقاط وإزالة المكررات
    const uniqueRecs = this.deduplicateAndRank(recommendations);
    const limitedRecs = uniqueRecs.slice(0, input.limit || 10);
    
    // حفظ التوصيات في قاعدة البيانات
    await this.saveRecommendations(input, limitedRecs);
    
    return limitedRecs;
  }

  /**
   * مركبات مشابهة للمركبة الحالية
   */
  private async getSimilarVehicles(input: RecommendationInput): Promise<RecommendationResult[]> {
    if (!input.currentVehicleId) return [];

    const currentVehicle = await db
      .select()
      .from(vehicles)
      .where(eq(vehicles.id, input.currentVehicleId))
      .limit(1);

    if (!currentVehicle.length) return [];

    const vehicle = currentVehicle[0];
    
    const similarVehicles = await db
      .select()
      .from(vehicles)
      .where(
        and(
          eq(vehicles.categoryId, vehicle.categoryId),
          eq(vehicles.regionId, vehicle.regionId),
          eq(vehicles.isActive, true),
          eq(vehicles.isApproved, true),
          ne(vehicles.id, vehicle.id)
        )
      )
      .orderBy(desc(vehicles.rating))
      .limit(5);

    return similarVehicles.map((v, index) => ({
      vehicleId: v.id,
      score: 0.9 - (index * 0.1),
      type: 'similar',
      reason: 'مركبة مشابهة في نفس التصنيف والمنطقة',
      metadata: {
        category: vehicle.categoryId,
        region: vehicle.regionId,
        basedOn: vehicle.id
      }
    }));
  }

  /**
   * المركبات الرائجة حالياً
   */
  private async getTrendingVehicles(input: RecommendationInput): Promise<RecommendationResult[]> {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    // المركبات الأكثر مشاهدة في الأسبوع الماضي
    const trendingQuery = await db
      .select({
        vehicleId: userInteractions.vehicleId,
        interactionCount: sql<number>`count(*)`.mapWith(Number)
      })
      .from(userInteractions)
      .where(
        and(
          gte(userInteractions.createdAt, oneWeekAgo),
          eq(userInteractions.interactionType, 'view')
        )
      )
      .groupBy(userInteractions.vehicleId)
      .orderBy(desc(sql`count(*)`))
      .limit(5);

    const vehicleIds = trendingQuery.map(t => t.vehicleId);
    if (!vehicleIds.length) return [];

    const trendingVehicles = await db
      .select()
      .from(vehicles)
      .where(
        and(
          inArray(vehicles.id, vehicleIds),
          eq(vehicles.isActive, true),
          eq(vehicles.isApproved, true)
        )
      );

    return trendingVehicles.map((v, index) => ({
      vehicleId: v.id,
      score: 0.8 - (index * 0.05),
      type: 'trending',
      reason: 'رائج هذا الأسبوع',
      metadata: {
        views: trendingQuery.find(t => t.vehicleId === v.id)?.interactionCount || 0
      }
    }));
  }

  /**
   * توصيات مخصصة بناءً على سجل البحث
   */
  private async getPersonalizedRecommendations(input: RecommendationInput): Promise<RecommendationResult[]> {
    if (!input.customerId && !input.sessionId) return [];

    // الحصول على سجل البحث الأخير
    const recentSearches = await db
      .select()
      .from(searchHistory)
      .where(
        input.customerId 
          ? eq(searchHistory.customerId, input.customerId)
          : eq(searchHistory.sessionId, input.sessionId)
      )
      .orderBy(desc(searchHistory.createdAt))
      .limit(5);

    if (!recentSearches.length) return [];

    // تحليل الأنماط من سجل البحث
    const preferredCategories = [...new Set(recentSearches
      .filter(s => s.categoryId)
      .map(s => s.categoryId!)
    )];
    
    const preferredRegions = [...new Set(recentSearches
      .filter(s => s.regionId)
      .map(s => s.regionId!)
    )];

    if (!preferredCategories.length && !preferredRegions.length) return [];

    const personalizedVehicles = await db
      .select()
      .from(vehicles)
      .where(
        and(
          or(
            preferredCategories.length ? inArray(vehicles.categoryId, preferredCategories) : undefined,
            preferredRegions.length ? inArray(vehicles.regionId, preferredRegions) : undefined
          ),
          eq(vehicles.isActive, true),
          eq(vehicles.isApproved, true)
        )
      )
      .orderBy(desc(vehicles.rating), desc(vehicles.totalReviews))
      .limit(6);

    return personalizedVehicles.map((v, index) => ({
      vehicleId: v.id,
      score: 0.85 - (index * 0.08),
      type: 'personalized',
      reason: 'مناسب لاهتماماتك بناءً على عمليات البحث السابقة',
      metadata: {
        matchedCategories: preferredCategories.includes(v.categoryId),
        matchedRegions: preferredRegions.includes(v.regionId)
      }
    }));
  }

  /**
   * الأكثر شعبية في التصنيف
   */
  private async getPopularInCategory(input: RecommendationInput): Promise<RecommendationResult[]> {
    const categoryId = input.categoryId;
    if (!categoryId) return [];

    const popularVehicles = await db
      .select()
      .from(vehicles)
      .where(
        and(
          eq(vehicles.categoryId, categoryId),
          eq(vehicles.isActive, true),
          eq(vehicles.isApproved, true)
        )
      )
      .orderBy(desc(vehicles.bookingCount), desc(vehicles.rating))
      .limit(4);

    return popularVehicles.map((v, index) => ({
      vehicleId: v.id,
      score: 0.75 - (index * 0.1),
      type: 'popular',
      reason: 'الأكثر حجزاً في هذا التصنيف',
      metadata: {
        bookingCount: v.bookingCount,
        rating: v.rating
      }
    }));
  }

  /**
   * إزالة المكررات والترتيب حسب النقاط
   */
  private deduplicateAndRank(recommendations: RecommendationResult[]): RecommendationResult[] {
    const uniqueMap = new Map<number, RecommendationResult>();
    
    for (const rec of recommendations) {
      const existing = uniqueMap.get(rec.vehicleId);
      if (!existing || rec.score > existing.score) {
        uniqueMap.set(rec.vehicleId, rec);
      }
    }
    
    return Array.from(uniqueMap.values())
      .sort((a, b) => b.score - a.score);
  }

  /**
   * حفظ التوصيات في قاعدة البيانات
   */
  private async saveRecommendations(
    input: RecommendationInput, 
    recs: RecommendationResult[]
  ): Promise<void> {
    if (!recs.length) return;

    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24); // تنتهي صلاحية التوصيات بعد 24 ساعة

    const recommendationsToInsert = recs.map(rec => ({
      sessionId: input.sessionId,
      customerId: input.customerId,
      vehicleId: rec.vehicleId,
      recommendationType: rec.type,
      score: rec.score.toString(),
      reason: rec.reason,
      metadata: rec.metadata,
      expiresAt
    }));

    await db.insert(recommendations).values(recommendationsToInsert);
  }

  /**
   * تسجيل تفاعل المستخدم
   */
  async trackUserInteraction(
    sessionId: string,
    customerId: number | undefined,
    vehicleId: number,
    interactionType: 'view' | 'click' | 'save' | 'share' | 'book',
    source: string = 'unknown',
    duration?: number,
    metadata?: any
  ): Promise<void> {
    await db.insert(userInteractions).values({
      sessionId,
      customerId,
      vehicleId,
      interactionType,
      duration,
      source,
      metadata
    });
  }

  /**
   * تسجيل عملية البحث
   */
  async trackSearch(
    sessionId: string,
    customerId: number | undefined,
    searchQuery: string | undefined,
    categoryId: number | undefined,
    regionId: number | undefined,
    priceRange: { min: number; max: number } | undefined,
    filters: any | undefined,
    resultsCount: number,
    clickedVehicleIds: number[] = [],
    userAgent?: string,
    ipAddress?: string
  ): Promise<void> {
    await db.insert(searchHistory).values({
      sessionId,
      customerId,
      searchQuery,
      categoryId,
      regionId,
      priceRange,
      filters,
      resultsCount,
      clickedVehicleIds: clickedVehicleIds,
      userAgent,
      ipAddress
    });
  }

  /**
   * تحديث حالة التوصية عند العرض
   */
  async markRecommendationAsShown(recommendationId: number): Promise<void> {
    await db
      .update(recommendations)
      .set({ shown: true })
      .where(eq(recommendations.id, recommendationId));
  }

  /**
   * تحديث حالة التوصية عند النقر
   */
  async markRecommendationAsClicked(recommendationId: number): Promise<void> {
    await db
      .update(recommendations)
      .set({ clicked: true })
      .where(eq(recommendations.id, recommendationId));
  }
}

export const recommendationEngine = new RecommendationEngine();