import {
  vehicles,
  bookings,
  categories,
  regions,
  partners,
  cateringServices,
  cookingServices,
  type Vehicle,
  type InsertVehicle,
  type Booking,
  type InsertBooking,
  type Category,
  type InsertCategory,
  type Region,
  type InsertRegion,
  type Partner,
  type InsertPartner,
  type CateringService,
  type InsertCateringService,
  type CookingService,
  type InsertCookingService,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, like, ilike, or } from "drizzle-orm";

export interface IStorage {
  // Vehicle operations
  getAllVehicles(): Promise<Vehicle[]>;
  getVehicleById(id: number): Promise<Vehicle | undefined>;
  getVehiclesByCategory(category: string): Promise<Vehicle[]>;
  getVehiclesByRegion(regionSlug: string): Promise<Vehicle[]>;
  searchVehicles(query: string, category?: string, tripType?: string, vehicleType?: string, regionSlug?: string): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  
  // Booking operations
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingById(id: number): Promise<Booking | undefined>;
  getBookingsByVehicle(vehicleId: number): Promise<Booking[]>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  
  // Region operations
  getAllRegions(): Promise<Region[]>;
  getRegionById(id: number): Promise<Region | undefined>;
  getRegionBySlug(slug: string): Promise<Region | undefined>;
  createRegion(region: InsertRegion): Promise<Region>;
  
  // Partner operations
  getAllPartners(): Promise<Partner[]>;
  getPartnerById(id: number): Promise<Partner | undefined>;
  createPartner(partner: InsertPartner): Promise<Partner>;
  updatePartnerStatus(id: number, status: string): Promise<Partner | undefined>;
  
  // Catering operations
  getAllCateringServices(): Promise<CateringService[]>;
  getCateringServicesByRegion(regionSlug: string): Promise<CateringService[]>;
  createCateringService(service: InsertCateringService): Promise<CateringService>;
  
  // Cooking operations
  getAllCookingServices(): Promise<CookingService[]>;
  getCookingServicesByRegion(regionSlug: string): Promise<CookingService[]>;
  createCookingService(service: InsertCookingService): Promise<CookingService>;
  
  // User operations (keeping existing)
  getUser(id: number): Promise<any>;
  getUserByUsername(username: string): Promise<any>;
  createUser(user: any): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  
  constructor() {
    this.seedData();
  }
  
  private async seedData() {
    try {
      // Seed regions first
      const existingRegions = await db.select().from(regions);
      if (existingRegions.length === 0) {
        await this.createInitialRegions();
      }
      
      // Seed categories
      const existingCategories = await db.select().from(categories);
      if (existingCategories.length === 0) {
        await this.createInitialCategories();
      }
      
      // Seed partners
      const existingPartners = await db.select().from(partners);
      if (existingPartners.length === 0) {
        await this.createInitialPartners();
      }
      
      // Seed initial vehicles with sample data from Hail region
      const existingVehicles = await db.select().from(vehicles);
      if (existingVehicles.length === 0) {
        await this.createInitialVehicles();
      }
    } catch (error) {
      console.error("Error seeding data:", error);
    }
  }
  
  private async createInitialRegions() {
    const regionData: InsertRegion[] = [
      {
        name: "Hail Region",
        nameAr: "منطقة حائل",
        slug: "hail",
        description: "Beautiful mountain landscapes and authentic desert experiences",
        descriptionAr: "مناظر جبلية خلابة وتجارب صحراوية أصيلة",
        imageUrl: "/images/regions/hail.jpg",
      },
      {
        name: "Eastern Province",
        nameAr: "المنطقة الشرقية",
        slug: "eastern",
        description: "Coastal adventures and marine activities",
        descriptionAr: "مغامرات ساحلية وأنشطة بحرية",
        imageUrl: "/images/regions/eastern.jpg",
      },
      {
        name: "Tabuk Region",
        nameAr: "منطقة تبوك",
        slug: "tabuk",
        description: "Red Sea coastline and mountain adventures",
        descriptionAr: "ساحل البحر الأحمر ومغامرات جبلية",
        imageUrl: "/images/regions/tabuk.jpg",
      },
      {
        name: "Aseer Region",
        nameAr: "منطقة عسير",
        slug: "aseer",
        description: "Green mountains and cool weather",
        descriptionAr: "جبال خضراء وطقس معتدل",
        imageUrl: "/images/regions/aseer.jpg",
      },
      {
        name: "Al Bahah Region",
        nameAr: "منطقة الباحة",
        slug: "albahah",
        description: "Forest areas and mountain retreats",
        descriptionAr: "مناطق غابات ومنتجعات جبلية",
        imageUrl: "/images/regions/albahah.jpg",
      },
    ];
    
    for (const region of regionData) {
      await db.insert(regions).values(region);
    }
  }
  
  private async createInitialCategories() {
    const categoryData: InsertCategory[] = [
      {
        name: "Desert Camping",
        nameAr: "كشتات البر",
        description: "Complete desert camping experiences",
        descriptionAr: "تجارب كشتات كاملة في البر",
        icon: "tent",
        slug: "desert_camping",
        vehicleCount: 25,
        bgImage: "/images/categories/desert.jpg",
        color: "#D97706",
      },
      {
        name: "Marine Adventures",
        nameAr: "مغامرات بحرية",
        description: "Boats, yachts and water sports",
        descriptionAr: "قوارب ويخوت ورياضات مائية",
        icon: "anchor",
        slug: "marine_trips",
        vehicleCount: 18,
        bgImage: "/images/categories/marine.jpg",
        color: "#0EA5E9",
      },
      {
        name: "ATV Adventures",
        nameAr: "مغامرات الدبابات",
        description: "Off-road ATV and quad adventures",
        descriptionAr: "مغامرات الدبابات والكوادز",
        icon: "motorcycle",
        slug: "atv_adventures",
        vehicleCount: 20,
        bgImage: "/images/categories/atv.jpg",
        color: "#DC2626",
      },
      {
        name: "Catering Services",
        nameAr: "خدمات الضيافة",
        description: "Food and beverage services",
        descriptionAr: "خدمات الطعام والمشروبات",
        icon: "coffee",
        slug: "catering",
        vehicleCount: 15,
        bgImage: "/images/categories/catering.jpg",
        color: "#059669",
      },
    ];
    
    for (const category of categoryData) {
      await db.insert(categories).values(category);
    }
  }
  
  private async createInitialPartners() {
    const [hailRegion] = await db.select().from(regions).where(eq(regions.slug, "hail"));
    const [easternRegion] = await db.select().from(regions).where(eq(regions.slug, "eastern"));
    
    if (!hailRegion || !easternRegion) return;
    
    const partnerData: InsertPartner[] = [
      {
        name: "Hail Adventure Co",
        nameAr: "شركة مغامرات حائل",
        email: "info@hailadventure.sa",
        phone: "+966501234567",
        regionId: hailRegion.id,
        businessType: "vehicle_rental",
        businessTypeAr: "تأجير مركبات",
        status: "approved",
        rating: "4.8",
        totalBookings: 150,
        // approvedAt: new Date(),
        commissionRate: "15.00",
      },
      {
        name: "Eastern Marine Services",
        nameAr: "خدمات شرقية بحرية",
        email: "contact@easternmarine.sa",
        phone: "+966507654321",
        regionId: easternRegion.id,
        businessType: "vehicle_rental",
        businessTypeAr: "تأجير مركبات",
        status: "approved",
        rating: "4.6",
        totalBookings: 89,
        // approvedAt: new Date(),
        commissionRate: "12.00",
      },
    ];
    
    for (const partner of partnerData) {
      await db.insert(partners).values(partner);
    }
  }

  private async createInitialVehicles() {
    const vehicleData: InsertVehicle[] = [
      {
        name: "Complete Desert Camp with Car",
        nameAr: "كشتة كاملة مع سيارة",
        description: "Full desert camping experience with 4WD vehicle in Hail region",
        descriptionAr: "تجربة كشتة صحراوية كاملة مع سيارة دفع رباعي في منطقة حائل",
        category: "desert_camping",
        categoryAr: "كشتات البر",
        subcategory: "with_car",
        subcategoryAr: "مع سيارة",
        pricePerDay: "800.00",
        imageUrl: "/api/placeholder/800/600",
        rating: "4.9",
        available: true,
        features: ["4WD Car", "Desert Tent", "Camping Equipment", "Barbecue Setup", "Solar Power"],
        featuresAr: ["سيارة دفع رباعي", "خيمة صحراوية", "معدات كشتة", "شواية", "طاقة شمسية"],
        location: "Hail Desert",
        locationAr: "صحراء حائل",
        region: "hail",
        regionAr: "حائل",
        capacity: 8
      },
      {
        name: "Traditional Desert Sessions",
        nameAr: "جلسات بر تراثية",
        description: "Traditional desert seating arrangements without vehicle",
        descriptionAr: "جلسات صحراوية تراثية بدون سيارة",
        category: "desert_camping",
        categoryAr: "كشتات البر",
        subcategory: "sessions_only",
        subcategoryAr: "جلسات فقط",
        pricePerDay: "300.00",
        imageUrl: "/api/placeholder/800/600",
        rating: "4.7",
        available: true,
        features: ["Traditional Seating", "Coffee Setup", "Fire Pit", "Desert Rugs"],
        featuresAr: ["جلسة تراثية", "إعداد قهوة", "موقد نار", "سجاد صحراوي"],
        location: "Hail Plains",
        locationAr: "سهول حائل",
        region: "hail",
        regionAr: "حائل",
        capacity: 15
      },
      {
        name: "Premium Desert Tent",
        nameAr: "خيمة صحراوية فاخرة",
        description: "Luxury desert tent setup without vehicle",
        descriptionAr: "إعداد خيمة صحراوية فاخرة بدون سيارة",
        category: "desert_camping",
        categoryAr: "كشتات البر",
        subcategory: "tents_only",
        subcategoryAr: "خيام فقط",
        pricePerDay: "500.00",
        imageUrl: "/api/placeholder/800/600",
        rating: "4.8",
        available: true,
        features: ["Luxury Tent", "Air Conditioning", "Private Bathroom", "Desert View"],
        featuresAr: ["خيمة فاخرة", "تكييف", "حمام خاص", "إطلالة صحراوية"],
        location: "Hail Dunes",
        locationAr: "كثبان حائل",
        region: "hail",
        regionAr: "حائل",
        capacity: 6
      },
    ];
    
    for (const vehicle of vehicleData) {
      await db.insert(vehicles).values(vehicle);
    }
  }

  // Vehicle operations
  async getAllVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles);
  }

  async getVehicleById(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }

  async getVehiclesByCategory(category: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.category, category));
  }

  async getVehiclesByRegion(regionSlug: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.region, regionSlug));
  }

  async searchVehicles(query: string, category?: string, tripType?: string, vehicleType?: string, regionSlug?: string): Promise<Vehicle[]> {
    let queryBuilder = db.select().from(vehicles);
    const conditions = [];

    if (query) {
      conditions.push(
        or(
          ilike(vehicles.name, `%${query}%`),
          ilike(vehicles.nameAr, `%${query}%`),
          ilike(vehicles.description, `%${query}%`)
        )
      );
    }

    if (category && category !== "all") {
      conditions.push(eq(vehicles.category, category));
    }

    if (regionSlug && regionSlug !== "all") {
      conditions.push(eq(vehicles.region, regionSlug));
    }

    if (vehicleType && vehicleType !== "all") {
      conditions.push(eq(vehicles.subcategory, vehicleType));
    }

    if (conditions.length > 0) {
      queryBuilder = queryBuilder.where(and(...conditions));
    }

    return await queryBuilder;
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const [newVehicle] = await db.insert(vehicles).values(vehicle).returning();
    return newVehicle;
  }

  // Booking operations
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingsByVehicle(vehicleId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.vehicleId, vehicleId));
  }

  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  // Region operations
  async getAllRegions(): Promise<Region[]> {
    return await db.select().from(regions).where(eq(regions.active, true));
  }

  async getRegionById(id: number): Promise<Region | undefined> {
    const [region] = await db.select().from(regions).where(eq(regions.id, id));
    return region;
  }

  async getRegionBySlug(slug: string): Promise<Region | undefined> {
    const [region] = await db.select().from(regions).where(eq(regions.slug, slug));
    return region;
  }

  async createRegion(region: InsertRegion): Promise<Region> {
    const [newRegion] = await db.insert(regions).values(region).returning();
    return newRegion;
  }

  // Partner operations
  async getAllPartners(): Promise<Partner[]> {
    return await db.select().from(partners);
  }

  async getPartnerById(id: number): Promise<Partner | undefined> {
    const [partner] = await db.select().from(partners).where(eq(partners.id, id));
    return partner;
  }

  async createPartner(partner: InsertPartner): Promise<Partner> {
    const [newPartner] = await db.insert(partners).values(partner).returning();
    return newPartner;
  }

  async updatePartnerStatus(id: number, status: string): Promise<Partner | undefined> {
    const [updatedPartner] = await db
      .update(partners)
      .set({ status, approvedAt: status === "approved" ? new Date() : null })
      .where(eq(partners.id, id))
      .returning();
    return updatedPartner;
  }

  // Catering operations
  async getAllCateringServices(): Promise<CateringService[]> {
    return await db.select().from(cateringServices).where(eq(cateringServices.available, true));
  }

  async getCateringServicesByRegion(regionSlug: string): Promise<CateringService[]> {
    const region = await this.getRegionBySlug(regionSlug);
    if (!region) return [];
    
    return await db.select().from(cateringServices)
      .where(and(eq(cateringServices.regionId, region.id), eq(cateringServices.available, true)));
  }

  async createCateringService(service: InsertCateringService): Promise<CateringService> {
    const [newService] = await db.insert(cateringServices).values(service).returning();
    return newService;
  }

  // Cooking operations
  async getAllCookingServices(): Promise<CookingService[]> {
    return await db.select().from(cookingServices).where(eq(cookingServices.available, true));
  }

  async getCookingServicesByRegion(regionSlug: string): Promise<CookingService[]> {
    const region = await this.getRegionBySlug(regionSlug);
    if (!region) return [];
    
    return await db.select().from(cookingServices)
      .where(and(eq(cookingServices.regionId, region.id), eq(cookingServices.available, true)));
  }

  async createCookingService(service: InsertCookingService): Promise<CookingService> {
    const [newService] = await db.insert(cookingServices).values(service).returning();
    return newService;
  }

  // User operations (keeping existing)
  async getUser(id: number): Promise<any> {
    return null; // To be implemented with auth system
  }

  async getUserByUsername(username: string): Promise<any> {
    return null; // To be implemented with auth system
  }

  async createUser(user: any): Promise<any> {
    return null; // To be implemented with auth system
  }
}

export const storage = new DatabaseStorage();