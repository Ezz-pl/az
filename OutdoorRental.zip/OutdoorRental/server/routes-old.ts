import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import Stripe from "stripe";

// تهيئة Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('مفتاح Stripe السري مفقود: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});
// import { db } from "./db";
// import { eq, and, desc, count, avg, sql } from "drizzle-orm";
import { reviews, reviewStats, reviewResponses, locations, vehicleLocations } from "@shared/schema";
import { 
  insertBookingSchema, 
  insertPartnerSchema, 
  insertCateringServiceSchema,
  insertCookingServiceSchema,
  insertRegionSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all vehicles with enhanced search
  app.get("/api/vehicles", async (req, res) => {
    try {
      const { category, search, tripType, vehicleType, region } = req.query;
      
      if (search || category || tripType || vehicleType || region) {
        const vehicles = await storage.searchVehicles(
          search as string || "", 
          category as string,
          tripType as string,
          vehicleType as string,
          region as string
        );
        res.json(vehicles);
      } else {
        const vehicles = await storage.getAllVehicles();
        res.json(vehicles);
      }
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  // Get vehicle by ID
  app.get("/api/vehicles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vehicle = await storage.getVehicleById(id);
      
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.json(vehicle);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicle" });
    }
  });

  // Get vehicles by category
  app.get("/api/vehicles/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const vehicles = await storage.getVehiclesByCategory(category);
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicles by category" });
    }
  });

  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Create booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create booking" });
      }
    }
  });

  // Get booking by ID
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBookingById(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  // === REGIONS API ===
  app.get("/api/regions", async (req, res) => {
    try {
      const regions = await storage.getAllRegions();
      res.json(regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });

  app.get("/api/regions/:slug", async (req, res) => {
    try {
      const region = await storage.getRegionBySlug(req.params.slug);
      if (!region) {
        return res.status(404).json({ message: "Region not found" });
      }
      res.json(region);
    } catch (error) {
      console.error("Error fetching region:", error);
      res.status(500).json({ message: "Failed to fetch region" });
    }
  });

  app.get("/api/regions/:slug/vehicles", async (req, res) => {
    try {
      const vehicles = await storage.getVehiclesByRegion(req.params.slug);
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching vehicles by region:", error);
      res.status(500).json({ message: "Failed to fetch vehicles for region" });
    }
  });

  // === PARTNERS API ===
  app.get("/api/partners", async (req, res) => {
    try {
      const partners = await storage.getAllPartners();
      res.json(partners);
    } catch (error) {
      console.error("Error fetching partners:", error);
      res.status(500).json({ message: "Failed to fetch partners" });
    }
  });

  app.get("/api/partners/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const partner = await storage.getPartnerById(id);
      if (!partner) {
        return res.status(404).json({ message: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      console.error("Error fetching partner:", error);
      res.status(500).json({ message: "Failed to fetch partner" });
    }
  });

  app.post("/api/partners", async (req, res) => {
    try {
      const validatedData = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(validatedData);
      res.status(201).json(partner);
    } catch (error) {
      console.error("Error creating partner:", error);
      res.status(400).json({ message: "Invalid partner data" });
    }
  });

  // Partner registration endpoint - new comprehensive system
  app.post("/api/partners/register", async (req, res) => {
    try {
      // استخراج البيانات من الطلب (بدون معالجة فعلية للصور مؤقتاً)
      const partnerData = {
        name: req.body.name || "شريك جديد",
        nameAr: req.body.nameAr || "شريك جديد",
        email: req.body.email || "partner@example.com",
        phone: req.body.phone || "0500000000",
        businessType: req.body.vehicleType || "other",
        businessTypeAr: req.body.vehicleType || "أخرى",
        description: req.body.description || "خدمة جديدة",
        features: req.body.features || "مزايا الخدمة",
        vehicleName: req.body.vehicleName || "مركبة",
        vehicleType: req.body.vehicleType || "other",
        regionId: parseInt(req.body.regionId || "1"),
        categoryId: parseInt(req.body.categoryId || "1"),
        status: "pending",
        images: ["partner_image_1.jpg", "partner_image_2.jpg", "partner_image_3.jpg", "partner_image_4.jpg", "partner_image_5.jpg"]
      };

      // محاكاة حفظ الطلب
      const application = {
        id: Math.floor(Math.random() * 1000) + 1,
        ...partnerData,
        submitedAt: new Date(),
        reviewedAt: null,
        adminNotes: null
      };
      
      res.json({ 
        message: "تم إرسال طلب الشراكة بنجاح", 
        application,
        status: "success"
      });
    } catch (error: any) {
      res.status(400).json({ 
        message: "فشل في إرسال طلب الشراكة", 
        error: error.message 
      });
    }
  });

  // Approve/Reject partner endpoints for admin
  app.patch("/api/admin/partners/:id/approve", async (req, res) => {
    try {
      const partnerId = parseInt(req.params.id);
      // محاكاة الموافقة على الشريك
      res.json({ message: "تمت الموافقة على الشريك بنجاح", partnerId });
    } catch (error: any) {
      res.status(500).json({ message: "خطأ في الموافقة على الشريك", error: error.message });
    }
  });

  app.patch("/api/admin/partners/:id/reject", async (req, res) => {
    try {
      const partnerId = parseInt(req.params.id);
      // محاكاة رفض الشريك
      res.json({ message: "تم رفض الطلب", partnerId });
    } catch (error: any) {
      res.status(500).json({ message: "خطأ في رفض الطلب", error: error.message });
    }
  });

  app.patch("/api/partners/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const partner = await storage.updatePartnerStatus(id, status);
      if (!partner) {
        return res.status(404).json({ message: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      console.error("Error updating partner status:", error);
      res.status(500).json({ message: "Failed to update partner status" });
    }
  });

  // === CATERING SERVICES API ===
  app.get("/api/catering", async (req, res) => {
    try {
      const { region } = req.query;
      if (region) {
        const services = await storage.getCateringServicesByRegion(region as string);
        res.json(services);
      } else {
        const services = await storage.getAllCateringServices();
        res.json(services);
      }
    } catch (error) {
      console.error("Error fetching catering services:", error);
      res.status(500).json({ message: "Failed to fetch catering services" });
    }
  });

  app.post("/api/catering", async (req, res) => {
    try {
      const validatedData = insertCateringServiceSchema.parse(req.body);
      const service = await storage.createCateringService(validatedData);
      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating catering service:", error);
      res.status(400).json({ message: "Invalid catering service data" });
    }
  });

  // === COOKING SERVICES API ===
  app.get("/api/cooking", async (req, res) => {
    try {
      const { region } = req.query;
      if (region) {
        const services = await storage.getCookingServicesByRegion(region as string);
        res.json(services);
      } else {
        const services = await storage.getAllCookingServices();
        res.json(services);
      }
    } catch (error) {
      console.error("Error fetching cooking services:", error);
      res.status(500).json({ message: "Failed to fetch cooking services" });
    }
  });

  app.post("/api/cooking", async (req, res) => {
    try {
      const validatedData = insertCookingServiceSchema.parse(req.body);
      const service = await storage.createCookingService(validatedData);
      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating cooking service:", error);
      res.status(400).json({ message: "Invalid cooking service data" });
    }
  });

  // === REVIEWS API ===
  app.post("/api/reviews", async (req, res) => {
    try {
      const reviewData = req.body;
      
      if (!reviewData.serviceType || !reviewData.serviceId || !reviewData.customerName || !reviewData.rating) {
        return res.status(400).json({ error: "معلومات التقييم غير مكتملة" });
      }

      const newReview = {
        id: Date.now(),
        serviceType: reviewData.serviceType,
        serviceId: reviewData.serviceId,
        customerName: reviewData.customerName,
        customerEmail: reviewData.customerEmail,
        rating: reviewData.rating,
        title: reviewData.title,
        comment: reviewData.comment,
        pros: reviewData.pros || [],
        cons: reviewData.cons || [],
        verified: false,
        helpful: 0,
        createdAt: new Date().toISOString()
      };

      res.json(newReview);
    } catch (error) {
      console.error("خطأ في إنشاء التقييم:", error);
      res.status(500).json({ error: "حدث خطأ أثناء إنشاء التقييم" });
    }
  });

  app.get("/api/reviews/:serviceType/:serviceId", async (req, res) => {
    try {
      const mockReviews = [
        {
          id: 1,
          customerName: "أحمد الشهري",
          rating: 5,
          title: "تجربة رائعة",
          comment: "استمتعت جداً بالرحلة، المركبة في حالة ممتازة والخدمة احترافية",
          pros: ["نظافة المركبة", "سهولة القيادة", "خدمة عملاء ممتازة"],
          cons: [],
          verified: true,
          helpful: 5,
          createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
        },
        {
          id: 2,
          customerName: "سارة العتيبي",
          rating: 4,
          title: "جيدة جداً",
          comment: "تجربة جميلة لكن يمكن تحسين بعض الأمور",
          pros: ["سعر مناسب", "موقع جيد"],
          cons: ["وقت الاستلام طويل قليلاً"],
          verified: true,
          helpful: 3,
          createdAt: new Date(Date.now() - 86400000 * 7).toISOString(),
        },
        {
          id: 3,
          customerName: "محمد القحطاني",
          rating: 5,
          title: "ممتازة للعائلة",
          comment: "المركبة مناسبة جداً للرحلات العائلية، مريحة وآمنة",
          pros: ["مساحة كبيرة", "مناسبة للأطفال", "خدمة توصيل"],
          cons: [],
          verified: true,
          helpful: 8,
          createdAt: new Date(Date.now() - 86400000 * 14).toISOString(),
        }
      ];

      res.json(mockReviews);
    } catch (error) {
      console.error("خطأ في جلب التقييمات:", error);
      res.status(500).json({ error: "حدث خطأ أثناء جلب التقييمات" });
    }
  });

  app.get("/api/reviews/:serviceType/:serviceId/stats", async (req, res) => {
    try {
      const mockStats = {
        totalReviews: 3,
        averageRating: 4.7,
        ratingDistribution: { "5": 2, "4": 1, "3": 0, "2": 0, "1": 0 }
      };

      res.json(mockStats);
    } catch (error) {
      console.error("خطأ في جلب إحصائيات التقييمات:", error);
      res.status(500).json({ error: "حدث خطأ أثناء جلب الإحصائيات" });
    }
  });

  // === LOCATIONS API ===
  app.get("/api/locations", async (req, res) => {
    try {
      const mockLocations = [
        {
          id: 1,
          name: "Desert Adventure Base - Riyadh",
          nameAr: "قاعدة مغامرات الصحراء - الرياض",
          address: "Exit 5, Riyadh-Dammam Highway",
          addressAr: "المخرج 5، طريق الرياض-الدمام",
          latitude: 24.7136,
          longitude: 46.6753,
          type: "pickup_point",
          serviceTypes: ["vehicle"],
          amenities: ["parking", "restrooms", "fuel_station"],
          amenitiesAr: ["موقف سيارات", "دورات مياه", "محطة وقود"],
          accessible: true,
          workingHours: "24/7",
          contactPhone: "+966 11 123 4567",
          verified: true
        },
        {
          id: 2,
          name: "Red Sea Marina - Jeddah",
          nameAr: "مارينا البحر الأحمر - جدة",
          address: "Corniche Road, North Obhur",
          addressAr: "طريق الكورنيش، أبحر الشمالية",
          latitude: 21.6971,
          longitude: 39.1039,
          type: "pickup_point",
          serviceTypes: ["vehicle", "catering"],
          amenities: ["parking", "restrooms", "restaurant", "wifi"],
          amenitiesAr: ["موقف سيارات", "دورات مياه", "مطعم", "واي فاي"],
          accessible: true,
          workingHours: "6:00 AM - 10:00 PM",
          contactPhone: "+966 12 234 5678",
          verified: true
        },
        {
          id: 3,
          name: "Asir Mountains Camp",
          nameAr: "مخيم جبال عسير",
          address: "Abha-Khamis Mushait Road",
          addressAr: "طريق أبها-خميس مشيط",
          latitude: 18.2465,
          longitude: 42.5047,
          type: "destination",
          serviceTypes: ["vehicle", "catering"],
          amenities: ["parking", "restrooms", "cooking", "wifi"],
          amenitiesAr: ["موقف سيارات", "دورات مياه", "منطقة طبخ", "واي فاي"],
          accessible: false,
          workingHours: "Sunrise to Sunset",
          verified: true
        }
      ];

      res.json(mockLocations);
    } catch (error) {
      console.error("خطأ في جلب المواقع:", error);
      res.status(500).json({ error: "حدث خطأ أثناء جلب المواقع" });
    }
  });

  // === STRIPE PAYMENT API ===
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, bookingId, currency = 'sar' } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "مبلغ غير صحيح" });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // تحويل إلى هللة (الوحدة الصغرى للريال)
        currency: currency,
        metadata: {
          bookingId: bookingId || '',
        },
        payment_method_types: ['card'],
        // دعم طرق الدفع المحلية السعودية
        payment_method_options: {
          card: {
            request_three_d_secure: 'automatic',
          },
        },
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id
      });
    } catch (error: any) {
      console.error("خطأ في إنشاء PaymentIntent:", error);
      res.status(500).json({ 
        error: "حدث خطأ أثناء معالجة الدفع: " + error.message 
      });
    }
  });

  app.post("/api/confirm-payment", async (req, res) => {
    try {
      const { paymentIntentId, bookingId } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status === 'succeeded') {
        // تحديث حالة الحجز في قاعدة البيانات
        // await storage.updateBookingPaymentStatus(bookingId, 'paid');
        
        res.json({ 
          success: true, 
          message: "تم الدفع بنجاح",
          paymentIntent 
        });
      } else {
        res.status(400).json({ 
          success: false, 
          message: "الدفع لم يتم بعد" 
        });
      }
    } catch (error: any) {
      console.error("خطأ في تأكيد الدفع:", error);
      res.status(500).json({ 
        error: "حدث خطأ أثناء تأكيد الدفع: " + error.message 
      });
    }
  });

  // Webhook لاستقبال إشعارات Stripe
  app.post("/api/stripe-webhook", async (req, res) => {
    const sig = req.headers['stripe-signature'];
    
    if (!sig) {
      return res.status(400).send('Missing stripe signature');
    }

    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET || '');
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // معالجة الأحداث المختلفة
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        console.log('Payment succeeded:', paymentIntent.id);
        // تحديث قاعدة البيانات
        break;
      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        console.log('Payment failed:', failedPayment.id);
        break;
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    res.json({ received: true });
  });

  // === ADMIN DASHBOARD API ===
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const [vehicles, partners, bookings, regions] = await Promise.all([
        storage.getAllVehicles(),
        storage.getAllPartners(),
        [], // Will need to implement bookings query
        storage.getAllRegions()
      ]);

      const stats = {
        totalVehicles: vehicles.length,
        totalPartners: partners.length,
        activePartners: partners.filter(p => p.status === "approved").length,
        pendingPartners: partners.filter(p => p.status === "pending").length,
        totalRegions: regions.length,
        totalBookings: 0, // Will be implemented
        revenue: 0 // Will be calculated from bookings
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
