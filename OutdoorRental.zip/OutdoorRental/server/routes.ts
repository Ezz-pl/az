import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { recommendationEngine } from "./recommendation-engine";
import session from "express-session";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";

// Middleware للمصادقة
declare global {
  namespace Express {
    interface Request {
      user?: any;
      admin?: any;
      customer?: any;
      partner?: any;
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: JWT_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // مساعد للمصادقة
  const verifyToken = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: "Token required" });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (error) {
      return res.status(401).json({ message: "Invalid token" });
    }
  };

  // ======== CUSTOMER AUTH ROUTES ========
  // تسجيل دخول العملاء
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "البريد الإلكتروني وكلمة المرور مطلوبان" });
      }

      const customer = await storage.verifyCustomerPassword(email, password);
      if (!customer) {
        return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }

      if (!customer.isActive) {
        return res.status(403).json({ message: "حسابك معطل، يرجى التواصل مع الدعم" });
      }

      const token = jwt.sign(
        { id: customer.id, email: customer.email, role: 'customer' },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        customer: {
          id: customer.id,
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          isVerified: customer.isVerified
        }
      });
    } catch (error) {
      console.error("Customer login error:", error);
      res.status(500).json({ message: "خطأ في الخادم" });
    }
  });

  // تسجيل حساب جديد للعملاء
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { name, email, phone, password } = req.body;
      
      if (!name || !email || !phone || !password) {
        return res.status(400).json({ message: "جميع الحقول مطلوبة" });
      }

      if (password.length < 6) {
        return res.status(400).json({ message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" });
      }

      // التحقق من وجود البريد الإلكتروني
      const existingCustomer = await storage.getCustomerByEmail(email);
      if (existingCustomer) {
        return res.status(400).json({ message: "البريد الإلكتروني مسجل مسبقاً" });
      }

      const customer = await storage.createCustomer({
        name,
        email,
        phone,
        password
      });

      const token = jwt.sign(
        { id: customer.id, email: customer.email, role: 'customer' },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        customer: {
          id: customer.id,
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          isVerified: customer.isVerified
        },
        message: "تم إنشاء الحساب بنجاح"
      });
    } catch (error) {
      console.error("Customer registration error:", error);
      res.status(500).json({ message: "خطأ في إنشاء الحساب" });
    }
  });

  // التحقق من حالة تسجيل الدخول
  app.get('/api/auth/me', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'customer') {
        return res.status(403).json({ message: "غير مسموح" });
      }

      const customer = await storage.getCustomerById(req.user.id);
      if (!customer) {
        return res.status(404).json({ message: "العميل غير موجود" });
      }

      res.json({
        customer: {
          id: customer.id,
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          isVerified: customer.isVerified
        }
      });
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ message: "خطأ في الخادم" });
    }
  });

  // ======== ADMIN ROUTES ========
  // تسجيل دخول الإدارة
  app.post('/api/admin/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }

      const admin = await storage.verifyAdminPassword(username, password);
      if (!admin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: admin.id, username: admin.username, role: 'admin' },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        admin: {
          id: admin.id,
          username: admin.username,
          name: admin.name,
          email: admin.email,
          role: admin.role,
          permissions: admin.permissions
        }
      });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // إحصائيات لوحة الإدارة
  app.get('/api/admin/dashboard', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Dashboard stats error:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // إدارة المدراء
  app.get('/api/admin/admins', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const admins = await storage.getAllAdmins();
      // إخفاء كلمات المرور
      const safeAdmins = admins.map(({ password, ...admin }) => admin);
      res.json(safeAdmins);
    } catch (error) {
      console.error("Error fetching admins:", error);
      res.status(500).json({ message: "Failed to fetch admins" });
    }
  });

  app.post('/api/admin/admins', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const admin = await storage.createAdmin({
        ...req.body,
        createdBy: req.user.username
      });
      
      const { password, ...safeAdmin } = admin;
      res.json(safeAdmin);
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Failed to create admin" });
    }
  });

  // إدارة العملاء
  app.get('/api/admin/customers', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const customers = await storage.getAllCustomers();
      const safeCustomers = customers.map(({ password, ...customer }) => customer);
      res.json(safeCustomers);
    } catch (error) {
      console.error("Error fetching customers:", error);
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.post('/api/admin/customers', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const customer = await storage.createCustomer(req.body);
      const { password, ...safeCustomer } = customer;
      res.json(safeCustomer);
    } catch (error) {
      console.error("Error creating customer:", error);
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  app.put('/api/admin/customers/:id', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const customer = await storage.updateCustomer(parseInt(req.params.id), req.body);
      const { password, ...safeCustomer } = customer;
      res.json(safeCustomer);
    } catch (error) {
      console.error("Error updating customer:", error);
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete('/api/admin/customers/:id', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      await storage.deleteCustomer(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting customer:", error);
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // إدارة الشركاء
  app.get('/api/admin/partners', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const status = req.query.status as string;
      const partners = status ? 
        await storage.getPartnersByStatus(status) : 
        await storage.getAllPartners();
        
      const safePartners = partners.map(({ password, ...partner }) => partner);
      res.json(safePartners);
    } catch (error) {
      console.error("Error fetching partners:", error);
      res.status(500).json({ message: "Failed to fetch partners" });
    }
  });

  app.post('/api/admin/partners', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const partner = await storage.createPartner(req.body);
      const { password, ...safePartner } = partner;
      res.json(safePartner);
    } catch (error) {
      console.error("Error creating partner:", error);
      res.status(500).json({ message: "Failed to create partner" });
    }
  });

  app.put('/api/admin/partners/:id/approve', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // موافقة الشريك وإنشاء كلمة مرور للدخول
      const partner = await storage.approvePartner(parseInt(req.params.id), req.user.id);
      
      // إنشاء كلمة مرور عشوائية للشريك
      const temporaryPassword = Math.random().toString(36).slice(-10);
      await storage.updatePartner(partner.id, { password: temporaryPassword });

      // الحصول على بيانات الشريك المحدثة
      const updatedPartner = await storage.getPartnerById(partner.id);
      
      res.json({ 
        partner: updatedPartner, 
        message: "تم قبول الشريك بنجاح وإنشاء حساب الدخول",
        loginCredentials: {
          email: partner.email,
          password: temporaryPassword,
          message: "يجب إرسال هذه البيانات للشريك عبر البريد الإلكتروني"
        }
      });
    } catch (error) {
      console.error("Error approving partner:", error);
      res.status(500).json({ message: "Failed to approve partner" });
    }
  });

  app.put('/api/admin/partners/:id/reject', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { reason } = req.body;
      const partner = await storage.rejectPartner(parseInt(req.params.id), reason || "لم يتم تقديم سبب");
      
      res.json({ partner, message: "تم رفض طلب الشريك" });
    } catch (error) {
      console.error("Error rejecting partner:", error);
      res.status(500).json({ message: "Failed to reject partner" });
    }
  });

  app.put('/api/admin/partners/:id/reject', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { reason } = req.body;
      const partner = await storage.rejectPartner(parseInt(req.params.id), reason || 'No reason provided');
      const { password, ...safePartner } = partner;
      res.json(safePartner);
    } catch (error) {
      console.error("Error rejecting partner:", error);
      res.status(500).json({ message: "Failed to reject partner" });
    }
  });

  // إدارة المناطق
  app.get('/api/admin/regions', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const regions = await storage.getAllRegions();
      res.json(regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });

  app.post('/api/admin/regions', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const region = await storage.createRegion(req.body);
      res.json(region);
    } catch (error) {
      console.error("Error creating region:", error);
      res.status(500).json({ message: "Failed to create region" });
    }
  });

  app.put('/api/admin/regions/:id', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const region = await storage.updateRegion(parseInt(req.params.id), req.body);
      res.json(region);
    } catch (error) {
      console.error("Error updating region:", error);
      res.status(500).json({ message: "Failed to update region" });
    }
  });

  // إدارة التصنيفات
  app.get('/api/admin/categories', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post('/api/admin/categories', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const category = await storage.createCategory(req.body);
      res.json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // إدارة المحتوى
  app.get('/api/admin/content', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const content = await storage.getAllContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.put('/api/admin/content/:key', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const content = await storage.updateContent(req.params.key, req.body, req.user.id);
      res.json(content);
    } catch (error) {
      console.error("Error updating content:", error);
      res.status(500).json({ message: "Failed to update content" });
    }
  });

  // إدارة الإعدادات
  app.get('/api/admin/settings', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.put('/api/admin/settings/:key', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { value } = req.body;
      const setting = await storage.updateSetting(req.params.key, value, req.user.id);
      res.json(setting);
    } catch (error) {
      console.error("Error updating setting:", error);
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // إدارة المركبات
  app.get('/api/admin/vehicles', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const vehicles = await storage.getAllVehicles();
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  app.put('/api/admin/vehicles/:id/approve', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const vehicle = await storage.approveVehicle(parseInt(req.params.id), req.user.id);
      res.json(vehicle);
    } catch (error) {
      console.error("Error approving vehicle:", error);
      res.status(500).json({ message: "Failed to approve vehicle" });
    }
  });

  // إدارة الحجوزات
  app.get('/api/admin/bookings', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // ======== PUBLIC ROUTES ========
  // عرض التصنيفات النشطة
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getActiveCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // عرض المناطق النشطة
  app.get('/api/regions', async (req, res) => {
    try {
      const regions = await storage.getActiveRegions();
      res.json(regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });

  // عرض المركبات المعتمدة
  app.get('/api/vehicles', async (req, res) => {
    try {
      const { search, category, region } = req.query;
      
      let vehicles;
      if (search) {
        vehicles = await storage.searchVehicles(search as string, {
          categoryId: category ? parseInt(category as string) : undefined,
          regionId: region ? parseInt(region as string) : undefined
        });
      } else if (category) {
        vehicles = await storage.getVehiclesByCategory(parseInt(category as string));
      } else if (region) {
        vehicles = await storage.getVehiclesByRegion(parseInt(region as string));
      } else {
        vehicles = await storage.getAllVehicles();
        // فلترة المركبات المعتمدة فقط للعرض العام
        vehicles = vehicles.filter(v => v.isActive && v.isApproved);
      }
      
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  // عرض تفاصيل المركبة
  app.get('/api/vehicles/:id', async (req, res) => {
    try {
      const vehicle = await storage.getVehicleById(parseInt(req.params.id));
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      // تحديث عدد المشاهدات - تم التعليق لأن viewCount غير موجود في المخطط
      // await storage.updateVehicle(vehicle.id, { 
      //   viewCount: (vehicle.viewCount || 0) + 1 
      // });
      
      res.json(vehicle);
    } catch (error) {
      console.error("Error fetching vehicle:", error);
      res.status(500).json({ message: "Failed to fetch vehicle" });
    }
  });

  // ======== CUSTOMER ROUTES ========
  // تسجيل عميل جديد
  app.post('/api/customers/register', async (req, res) => {
    try {
      const customer = await storage.createCustomer(req.body);
      const { password, ...safeCustomer } = customer;
      
      const token = jwt.sign(
        { id: customer.id, email: customer.email, role: 'customer' },
        JWT_SECRET,
        { expiresIn: '30d' }
      );

      res.json({ token, customer: safeCustomer });
    } catch (error) {
      console.error("Customer registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // تسجيل دخول العميل
  app.post('/api/customers/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const customer = await storage.verifyCustomerPassword(email, password);
      if (!customer) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: customer.id, email: customer.email, role: 'customer' },
        JWT_SECRET,
        { expiresIn: '30d' }
      );

      const { password: _, ...safeCustomer } = customer;
      res.json({ token, customer: safeCustomer });
    } catch (error) {
      console.error("Customer login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // ======== PARTNER ROUTES ========
  // تسجيل شريك جديد  
  app.post('/api/partners/register', async (req, res) => {
    try {
      // التحقق من البيانات المطلوبة
      const {
        contactName,
        businessName,
        businessNameAr,
        email,
        phone,
        businessType,
        businessDescription,
        experienceYears,
        regionId,
        address,
        serviceAreas,
        vehicleTypes,
        fleetSize,
        services,
        commercialRegister,
        taxNumber,
        licenseNumber
      } = req.body;

      // التحقق من عدم وجود شريك بنفس البريد الإلكتروني
      const existingPartner = await storage.getPartnerByEmail(email);
      if (existingPartner) {
        return res.status(400).json({ message: "البريد الإلكتروني مسجل بالفعل" });
      }

      // إنشاء الشريك مع حالة الانتظار
      const partnerData = {
        contactName,
        businessName,
        businessNameAr,
        email,
        phone,
        businessType,
        businessDescription: businessDescription,
        experienceYears,
        regionId: parseInt(regionId),
        address,
        serviceAreas,
        fleetSize,
        services,
        commercialRegister,
        taxNumber: taxNumber || null,
        licenseNumber,
        status: 'pending',
        isActive: false,
        isVerified: false,
        rating: 0,
        totalReviews: 0,
        // حفظ أنواع المركبات كـ JSON
        metadata: JSON.stringify({ vehicleTypes })
      };

      const partner = await storage.createPartner(partnerData);
      
      res.json({ 
        message: "تم إرسال الطلب بنجاح! سيتم مراجعته من قبل الإدارة", 
        partnerId: partner.id 
      });
    } catch (error) {
      console.error("Error creating partner:", error);
      res.status(500).json({ message: "فشل في إرسال الطلب" });
    }
  });

  // تسجيل دخول الشريك
  app.post('/api/partners/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const partner = await storage.verifyPartnerPassword(email, password);
      if (!partner) {
        return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }

      if (partner.status !== 'approved') {
        return res.status(401).json({ message: "حسابك غير مفعل بعد. يرجى انتظار موافقة الإدارة" });
      }

      const token = jwt.sign(
        { id: partner.id, email: partner.email, role: 'partner' },
        JWT_SECRET,
        { expiresIn: '30d' }
      );

      const { password: _, ...safePartner } = partner;
      res.json({ token, partner: safePartner });
    } catch (error) {
      console.error("Partner login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // إحصائيات الشريك
  app.get('/api/partners/stats', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'partner') {
        return res.status(403).json({ message: "Partner access required" });
      }

      // إحصائيات وهمية للوقت الحالي - ستصبح حقيقية عند إضافة بيانات الحجوزات
      const stats = {
        totalBookings: 0,
        pendingBookings: 0,
        totalRevenue: 0,
        monthlyRevenue: 0,
        averageRating: 0,
        totalVehicles: 0,
        activeVehicles: 0
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching partner stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // إضافة مركبة جديدة من الشريك
  app.post('/api/partners/vehicles', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'partner') {
        return res.status(403).json({ message: "Partner access required" });
      }

      const vehicleData = {
        ...req.body,
        partnerId: req.user.id,
        isActive: false, // تحتاج موافقة الإدارة
        isApproved: false
      };

      const vehicle = await storage.createVehicle(vehicleData);
      res.json({ 
        vehicle, 
        message: "تم إضافة المركبة بنجاح! سيتم مراجعتها من قبل الإدارة" 
      });
    } catch (error) {
      console.error("Error creating vehicle:", error);
      res.status(500).json({ message: "Failed to create vehicle" });
    }
  });

  // عرض مركبات الشريك
  app.get('/api/partners/vehicles', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'partner') {
        return res.status(403).json({ message: "Partner access required" });
      }

      const vehicles = await storage.getVehiclesByPartner(req.user.id);
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching partner vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  // تحديث مركبة الشريك
  app.put('/api/partners/vehicles/:id', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'partner') {
        return res.status(403).json({ message: "Partner access required" });
      }

      // التأكد أن المركبة تخص الشريك
      const existingVehicle = await storage.getVehicleById(parseInt(req.params.id));
      if (!existingVehicle || existingVehicle.partnerId !== req.user.id) {
        return res.status(404).json({ message: "Vehicle not found" });
      }

      const vehicle = await storage.updateVehicle(parseInt(req.params.id), {
        ...req.body,
        isApproved: false // إعادة المراجعة بعد التحديث
      });
      
      res.json({ 
        vehicle, 
        message: "تم تحديث المركبة بنجاح! سيتم مراجعة التعديلات" 
      });
    } catch (error) {
      console.error("Error updating vehicle:", error);
      res.status(500).json({ message: "Failed to update vehicle" });
    }
  });



  // إنشاء حجز جديد
  app.post('/api/bookings', verifyToken, async (req, res) => {
    try {
      if (req.user.role !== 'customer') {
        return res.status(403).json({ message: "Customer access required" });
      }

      const booking = await storage.createBooking({
        ...req.body,
        customerId: req.user.id
      });
      
      res.json(booking);
    } catch (error) {
      console.error("Booking creation error:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // ===== نظام التوصيات الذكية =====
  
  // الحصول على توصيات مخصصة
  app.get('/api/recommendations', async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const customerId = req.user?.id;
      const { vehicleId, categoryId, regionId, limit = 10 } = req.query;

      const recommendations = await recommendationEngine.generateRecommendations({
        sessionId,
        customerId,
        currentVehicleId: vehicleId ? parseInt(vehicleId as string) : undefined,
        categoryId: categoryId ? parseInt(categoryId as string) : undefined,
        regionId: regionId ? parseInt(regionId as string) : undefined,
        limit: parseInt(limit as string)
      });

      // جلب تفاصيل المركبات للتوصيات
      const vehicleIds = recommendations.map(r => r.vehicleId);
      const vehicles = await storage.getVehiclesByIds(vehicleIds);

      const enrichedRecommendations = recommendations.map(rec => {
        const vehicle = vehicles.find(v => v.id === rec.vehicleId);
        return {
          ...rec,
          vehicle
        };
      }).filter(rec => rec.vehicle); // إزالة التوصيات للمركبات غير الموجودة

      res.json(enrichedRecommendations);
    } catch (error) {
      console.error("Recommendations error:", error);
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  // تسجيل تفاعل المستخدم
  app.post('/api/interactions/track', async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const customerId = req.user?.id;
      const { vehicleId, interactionType, duration, source, metadata } = req.body;

      await recommendationEngine.trackUserInteraction(
        sessionId,
        customerId,
        vehicleId,
        interactionType,
        source || 'web',
        duration,
        metadata
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Track interaction error:", error);
      res.status(500).json({ message: "Failed to track interaction" });
    }
  });

  // تسجيل عملية البحث
  app.post('/api/search/track', async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const customerId = req.user?.id;
      const { 
        searchQuery, 
        categoryId, 
        regionId, 
        priceRange, 
        filters, 
        resultsCount, 
        clickedVehicleIds 
      } = req.body;

      await recommendationEngine.trackSearch(
        sessionId,
        customerId,
        searchQuery,
        categoryId,
        regionId,
        priceRange,
        filters,
        resultsCount,
        clickedVehicleIds || [],
        req.get('User-Agent'),
        req.ip
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Track search error:", error);
      res.status(500).json({ message: "Failed to track search" });
    }
  });

  // تحديث حالة التوصية عند العرض
  app.post('/api/recommendations/:id/shown', async (req, res) => {
    try {
      const recommendationId = parseInt(req.params.id);
      await recommendationEngine.markRecommendationAsShown(recommendationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark recommendation shown error:", error);
      res.status(500).json({ message: "Failed to mark recommendation as shown" });
    }
  });

  // تحديث حالة التوصية عند النقر
  app.post('/api/recommendations/:id/clicked', async (req, res) => {
    try {
      const recommendationId = parseInt(req.params.id);
      await recommendationEngine.markRecommendationAsClicked(recommendationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark recommendation clicked error:", error);
      res.status(500).json({ message: "Failed to mark recommendation as clicked" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}