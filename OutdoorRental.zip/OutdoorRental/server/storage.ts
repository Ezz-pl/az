import {
  admins,
  customers,
  partners,
  regions,
  categories,
  vehicles,
  bookings,
  reviews,
  content,
  settings,
  paymentMethods,
  type Admin,
  type InsertAdmin,
  type Customer,
  type InsertCustomer,
  type Partner,
  type InsertPartner,
  type Region,
  type Category,
  type Vehicle,
  type InsertVehicle,
  type Booking,
  type InsertBooking,
  type Review,
  type InsertReview,
  type Content,
  type Setting,
  type PaymentMethod,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike, sql, desc, asc, inArray } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // Admin operations
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  verifyAdminPassword(username: string, password: string): Promise<Admin | undefined>;
  updateAdminLastLogin(id: number): Promise<void>;
  getAllAdmins(): Promise<Admin[]>;
  updateAdmin(id: number, data: Partial<InsertAdmin>): Promise<Admin>;
  deleteAdmin(id: number): Promise<void>;

  // Customer operations
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  getCustomerById(id: number): Promise<Customer | undefined>;
  verifyCustomerPassword(email: string, password: string): Promise<Customer | undefined>;
  updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer>;
  getAllCustomers(): Promise<Customer[]>;
  deleteCustomer(id: number): Promise<void>;

  // Partner operations
  createPartner(partner: InsertPartner): Promise<Partner>;
  getPartnerByEmail(email: string): Promise<Partner | undefined>;
  getPartnerById(id: number): Promise<Partner | undefined>;
  verifyPartnerPassword(email: string, password: string): Promise<Partner | undefined>;
  updatePartner(id: number, data: Partial<InsertPartner>): Promise<Partner>;
  getAllPartners(): Promise<Partner[]>;
  getPartnersByStatus(status: string): Promise<Partner[]>;
  approvePartner(id: number, approvedBy: number): Promise<Partner>;
  rejectPartner(id: number, reason: string): Promise<Partner>;
  deletePartner(id: number): Promise<void>;

  // Region operations
  createRegion(region: Omit<Region, 'id' | 'createdAt'>): Promise<Region>;
  getAllRegions(): Promise<Region[]>;
  getActiveRegions(): Promise<Region[]>;
  updateRegion(id: number, data: Partial<Region>): Promise<Region>;
  deleteRegion(id: number): Promise<void>;

  // Category operations
  createCategory(category: Omit<Category, 'id' | 'createdAt'>): Promise<Category>;
  getAllCategories(): Promise<Category[]>;
  getActiveCategories(): Promise<Category[]>;
  updateCategory(id: number, data: Partial<Category>): Promise<Category>;
  deleteCategory(id: number): Promise<void>;

  // Vehicle operations
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  getAllVehicles(): Promise<Vehicle[]>;
  getVehicleById(id: number): Promise<Vehicle | undefined>;
  getVehiclesByPartner(partnerId: number): Promise<Vehicle[]>;
  getVehiclesByCategory(categoryId: number): Promise<Vehicle[]>;
  getVehiclesByRegion(regionId: number): Promise<Vehicle[]>;
  getVehiclesByIds(ids: number[]): Promise<Vehicle[]>;
  searchVehicles(query: string, filters?: any): Promise<Vehicle[]>;
  updateVehicle(id: number, data: Partial<InsertVehicle>): Promise<Vehicle>;
  approveVehicle(id: number, approvedBy: number): Promise<Vehicle>;
  deleteVehicle(id: number): Promise<void>;

  // Booking operations
  createBooking(booking: InsertBooking): Promise<Booking>;
  getAllBookings(): Promise<Booking[]>;
  getBookingById(id: number): Promise<Booking | undefined>;
  getBookingsByCustomer(customerId: number): Promise<Booking[]>;
  getBookingsByPartner(partnerId: number): Promise<Booking[]>;
  updateBookingStatus(id: number, status: string): Promise<Booking>;
  updateBooking(id: number, data: Partial<Booking>): Promise<Booking>;
  deleteBooking(id: number): Promise<void>;

  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getAllReviews(): Promise<Review[]>;
  getReviewsByVehicle(vehicleId: number): Promise<Review[]>;
  getReviewsByPartner(partnerId: number): Promise<Review[]>;
  updateReview(id: number, data: Partial<Review>): Promise<Review>;
  deleteReview(id: number): Promise<void>;

  // Content operations
  getContentByKey(key: string): Promise<Content | undefined>;
  updateContent(key: string, data: Partial<Content>, updatedBy: number): Promise<Content>;
  getAllContent(): Promise<Content[]>;
  createContent(content: Omit<Content, 'id' | 'updatedAt'>): Promise<Content>;
  deleteContent(key: string): Promise<void>;

  // Settings operations
  getSettingByKey(key: string): Promise<Setting | undefined>;
  updateSetting(key: string, value: string, updatedBy: number): Promise<Setting>;
  getAllSettings(): Promise<Setting[]>;
  createSetting(setting: Omit<Setting, 'id' | 'updatedAt'>): Promise<Setting>;
  deleteSetting(key: string): Promise<void>;

  // Payment method operations
  getAllPaymentMethods(): Promise<PaymentMethod[]>;
  getActivePaymentMethods(): Promise<PaymentMethod[]>;
  updatePaymentMethod(id: number, data: Partial<PaymentMethod>): Promise<PaymentMethod>;

  // Dashboard stats
  getDashboardStats(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // Admin operations
  async createAdmin(adminData: InsertAdmin): Promise<Admin> {
    const hashedPassword = await bcrypt.hash(adminData.password, 10);
    const [admin] = await db
      .insert(admins)
      .values({
        ...adminData,
        password: hashedPassword,
      })
      .returning();
    return admin;
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.username, username));
    return admin;
  }

  async verifyAdminPassword(username: string, password: string): Promise<Admin | undefined> {
    const admin = await this.getAdminByUsername(username);
    if (!admin || !admin.isActive) return undefined;
    
    const isValid = await bcrypt.compare(password, admin.password);
    if (!isValid) return undefined;
    
    await this.updateAdminLastLogin(admin.id);
    return admin;
  }

  async updateAdminLastLogin(id: number): Promise<void> {
    await db.update(admins)
      .set({ lastLogin: new Date() })
      .where(eq(admins.id, id));
  }

  async getAllAdmins(): Promise<Admin[]> {
    return await db.select().from(admins).orderBy(desc(admins.createdAt));
  }

  async updateAdmin(id: number, data: Partial<InsertAdmin>): Promise<Admin> {
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
    const [admin] = await db
      .update(admins)
      .set(data)
      .where(eq(admins.id, id))
      .returning();
    return admin;
  }

  async deleteAdmin(id: number): Promise<void> {
    await db.delete(admins).where(eq(admins.id, id));
  }

  // Customer operations
  async createCustomer(customerData: InsertCustomer): Promise<Customer> {
    const hashedPassword = await bcrypt.hash(customerData.password, 10);
    const [customer] = await db
      .insert(customers)
      .values({
        ...customerData,
        password: hashedPassword,
      })
      .returning();
    return customer;
  }

  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.email, email));
    return customer;
  }

  async getCustomerById(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async verifyCustomerPassword(email: string, password: string): Promise<Customer | undefined> {
    const customer = await this.getCustomerByEmail(email);
    if (!customer || !customer.isActive) return undefined;
    
    const isValid = await bcrypt.compare(password, customer.password);
    return isValid ? customer : undefined;
  }

  async updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer> {
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
    const [customer] = await db
      .update(customers)
      .set(data)
      .where(eq(customers.id, id))
      .returning();
    return customer;
  }

  async getAllCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async deleteCustomer(id: number): Promise<void> {
    await db.delete(customers).where(eq(customers.id, id));
  }

  // Partner operations
  async createPartner(partnerData: InsertPartner): Promise<Partner> {
    // تشفير كلمة المرور فقط إذا كانت موجودة
    const values = { ...partnerData };
    if (partnerData.password) {
      values.password = await bcrypt.hash(partnerData.password, 10);
    }
    
    const [partner] = await db
      .insert(partners)
      .values(values)
      .returning();
    return partner;
  }

  async getPartnerByEmail(email: string): Promise<Partner | undefined> {
    const [partner] = await db.select().from(partners).where(eq(partners.email, email));
    return partner;
  }

  async getPartnerById(id: number): Promise<Partner | undefined> {
    const [partner] = await db.select().from(partners).where(eq(partners.id, id));
    return partner;
  }

  async verifyPartnerPassword(email: string, password: string): Promise<Partner | undefined> {
    const partner = await this.getPartnerByEmail(email);
    if (!partner || !partner.isActive || !partner.password) return undefined;
    
    const isValid = await bcrypt.compare(password, partner.password);
    return isValid ? partner : undefined;
  }

  async updatePartner(id: number, data: Partial<InsertPartner>): Promise<Partner> {
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
    const [partner] = await db
      .update(partners)
      .set(data)
      .where(eq(partners.id, id))
      .returning();
    return partner;
  }

  async getAllPartners(): Promise<Partner[]> {
    return await db.select().from(partners).orderBy(desc(partners.createdAt));
  }

  async getPartnersByStatus(status: string): Promise<Partner[]> {
    return await db.select().from(partners)
      .where(eq(partners.status, status))
      .orderBy(desc(partners.createdAt));
  }

  async approvePartner(id: number, approvedBy: number): Promise<Partner> {
    const [partner] = await db
      .update(partners)
      .set({
        status: "approved",
        isActive: true,
        approvedAt: new Date(),
        approvedBy,
      })
      .where(eq(partners.id, id))
      .returning();
    return partner;
  }

  async rejectPartner(id: number, reason: string): Promise<Partner> {
    const [partner] = await db
      .update(partners)
      .set({
        status: "rejected",
        rejectionReason: reason,
      })
      .where(eq(partners.id, id))
      .returning();
    return partner;
  }

  async deletePartner(id: number): Promise<void> {
    await db.delete(partners).where(eq(partners.id, id));
  }

  // Region operations
  async createRegion(regionData: Omit<Region, 'id' | 'createdAt'>): Promise<Region> {
    const [region] = await db.insert(regions).values(regionData).returning();
    return region;
  }

  async getAllRegions(): Promise<Region[]> {
    return await db.select().from(regions).orderBy(asc(regions.nameAr));
  }

  async getActiveRegions(): Promise<Region[]> {
    return await db.select().from(regions)
      .where(eq(regions.isActive, true))
      .orderBy(asc(regions.nameAr));
  }

  async updateRegion(id: number, data: Partial<Region>): Promise<Region> {
    const [region] = await db
      .update(regions)
      .set(data)
      .where(eq(regions.id, id))
      .returning();
    return region;
  }

  async deleteRegion(id: number): Promise<void> {
    await db.delete(regions).where(eq(regions.id, id));
  }

  // Category operations
  async createCategory(categoryData: Omit<Category, 'id' | 'createdAt'>): Promise<Category> {
    const [category] = await db.insert(categories).values(categoryData).returning();
    return category;
  }

  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.nameAr));
  }

  async getActiveCategories(): Promise<Category[]> {
    return await db.select().from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(categories.sortOrder);
  }

  async updateCategory(id: number, data: Partial<Category>): Promise<Category> {
    const [category] = await db
      .update(categories)
      .set(data)
      .where(eq(categories.id, id))
      .returning();
    return category;
  }

  async deleteCategory(id: number): Promise<void> {
    await db.delete(categories).where(eq(categories.id, id));
  }

  // Vehicle operations
  async createVehicle(vehicleData: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(vehicleData).returning();
    return vehicle;
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    // عرض مركبات فارغة لأنه لا يوجد شركاء مسجلين بعد
    return [];
  }

  async getVehicleById(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }

  async getVehiclesByPartner(partnerId: number): Promise<Vehicle[]> {
    return await db.select().from(vehicles)
      .where(eq(vehicles.partnerId, partnerId))
      .orderBy(desc(vehicles.createdAt));
  }

  async getVehiclesByCategory(categoryId: number): Promise<Vehicle[]> {
    // عرض مركبات فارغة لأنه لا يوجد شركاء مسجلين بعد
    return [];
  }

  async getVehiclesByRegion(regionId: number): Promise<Vehicle[]> {
    // عرض مركبات فارغة لأنه لا يوجد شركاء مسجلين بعد
    return [];
  }

  async searchVehicles(query: string, filters?: any): Promise<Vehicle[]> {
    let conditions: any[] = [eq(vehicles.isActive, true), eq(vehicles.isApproved, true)];

    if (query) {
      conditions.push(
        or(
          ilike(vehicles.name, `%${query}%`),
          ilike(vehicles.nameAr, `%${query}%`),
          ilike(vehicles.description, `%${query}%`),
          ilike(vehicles.descriptionAr, `%${query}%`)
        )
      );
    }

    if (filters?.categoryId) {
      conditions.push(eq(vehicles.categoryId, filters.categoryId));
    }

    if (filters?.regionId) {
      conditions.push(eq(vehicles.regionId, filters.regionId));
    }

    return await db.select().from(vehicles)
      .where(and(...conditions))
      .orderBy(desc(vehicles.rating), desc(vehicles.createdAt));
  }

  async updateVehicle(id: number, data: Partial<InsertVehicle>): Promise<Vehicle> {
    const [vehicle] = await db
      .update(vehicles)
      .set(data)
      .where(eq(vehicles.id, id))
      .returning();
    return vehicle;
  }

  async approveVehicle(id: number, approvedBy: number): Promise<Vehicle> {
    const [vehicle] = await db
      .update(vehicles)
      .set({
        isApproved: true,
        approvedAt: new Date(),
        approvedBy,
      })
      .where(eq(vehicles.id, id))
      .returning();
    return vehicle;
  }

  async deleteVehicle(id: number): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }

  async getVehiclesByIds(ids: number[]): Promise<Vehicle[]> {
    if (ids.length === 0) return [];
    return await db.select().from(vehicles).where(inArray(vehicles.id, ids));
  }

  // Booking operations
  async createBooking(bookingData: InsertBooking): Promise<Booking> {
    const bookingNumber = `BK${Date.now()}`;
    const [booking] = await db
      .insert(bookings)
      .values({
        ...bookingData,
        bookingNumber,
      })
      .returning();
    return booking;
  }

  async getAllBookings(): Promise<Booking[]> {
    return await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingsByCustomer(customerId: number): Promise<Booking[]> {
    return await db.select().from(bookings)
      .where(eq(bookings.customerId, customerId))
      .orderBy(desc(bookings.createdAt));
  }

  async getBookingsByPartner(partnerId: number): Promise<Booking[]> {
    return await db.select().from(bookings)
      .where(eq(bookings.partnerId, partnerId))
      .orderBy(desc(bookings.createdAt));
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking> {
    const updateData: any = { status };
    
    if (status === "confirmed") {
      updateData.confirmedAt = new Date();
    } else if (status === "cancelled") {
      updateData.cancelledAt = new Date();
    }

    const [booking] = await db
      .update(bookings)
      .set(updateData)
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async updateBooking(id: number, data: Partial<Booking>): Promise<Booking> {
    const [booking] = await db
      .update(bookings)
      .set(data)
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async deleteBooking(id: number): Promise<void> {
    await db.delete(bookings).where(eq(bookings.id, id));
  }

  // Review operations
  async createReview(reviewData: InsertReview): Promise<Review> {
    const [review] = await db.insert(reviews).values(reviewData).returning();
    return review;
  }

  async getAllReviews(): Promise<Review[]> {
    return await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  }

  async getReviewsByVehicle(vehicleId: number): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(and(eq(reviews.vehicleId, vehicleId), eq(reviews.isVisible, true)))
      .orderBy(desc(reviews.createdAt));
  }

  async getReviewsByPartner(partnerId: number): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(and(eq(reviews.partnerId, partnerId), eq(reviews.isVisible, true)))
      .orderBy(desc(reviews.createdAt));
  }

  async updateReview(id: number, data: Partial<Review>): Promise<Review> {
    const [review] = await db
      .update(reviews)
      .set(data)
      .where(eq(reviews.id, id))
      .returning();
    return review;
  }

  async deleteReview(id: number): Promise<void> {
    await db.delete(reviews).where(eq(reviews.id, id));
  }

  // Content operations
  async getContentByKey(key: string): Promise<Content | undefined> {
    const [contentItem] = await db.select().from(content).where(eq(content.key, key));
    return contentItem;
  }

  async updateContent(key: string, data: Partial<Content>, updatedBy: number): Promise<Content> {
    const [existingContent] = await db.select().from(content).where(eq(content.key, key));
    
    if (existingContent) {
      const [updated] = await db
        .update(content)
        .set({
          ...data,
          updatedBy,
          updatedAt: new Date(),
        })
        .where(eq(content.key, key))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(content)
        .values({
          key,
          ...data,
          updatedBy,
        })
        .returning();
      return created;
    }
  }

  async getAllContent(): Promise<Content[]> {
    return await db.select().from(content).orderBy(asc(content.key));
  }

  async createContent(contentData: Omit<Content, 'id' | 'updatedAt'>): Promise<Content> {
    const [created] = await db.insert(content).values(contentData).returning();
    return created;
  }

  async deleteContent(key: string): Promise<void> {
    await db.delete(content).where(eq(content.key, key));
  }

  // Settings operations
  async getSettingByKey(key: string): Promise<Setting | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting;
  }

  async updateSetting(key: string, value: string, updatedBy: number): Promise<Setting> {
    const [existingSetting] = await db.select().from(settings).where(eq(settings.key, key));
    
    if (existingSetting) {
      const [updated] = await db
        .update(settings)
        .set({
          value,
          updatedBy,
          updatedAt: new Date(),
        })
        .where(eq(settings.key, key))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(settings)
        .values({
          key,
          value,
          type: "text",
          updatedBy,
        })
        .returning();
      return created;
    }
  }

  async getAllSettings(): Promise<Setting[]> {
    return await db.select().from(settings).orderBy(asc(settings.key));
  }

  async createSetting(settingData: Omit<Setting, 'id' | 'updatedAt'>): Promise<Setting> {
    const [created] = await db.insert(settings).values(settingData).returning();
    return created;
  }

  async deleteSetting(key: string): Promise<void> {
    await db.delete(settings).where(eq(settings.key, key));
  }

  // Payment method operations
  async getAllPaymentMethods(): Promise<PaymentMethod[]> {
    return await db.select().from(paymentMethods);
  }

  async getActivePaymentMethods(): Promise<PaymentMethod[]> {
    return await db.select().from(paymentMethods).where(eq(paymentMethods.isActive, true));
  }

  async updatePaymentMethod(id: number, data: Partial<PaymentMethod>): Promise<PaymentMethod> {
    const [updated] = await db
      .update(paymentMethods)
      .set(data)
      .where(eq(paymentMethods.id, id))
      .returning();
    return updated;
  }

  // Dashboard stats
  async getDashboardStats(): Promise<any> {
    const totalCustomers = await db.select({ count: sql<number>`count(*)` }).from(customers);
    const totalPartners = await db.select({ count: sql<number>`count(*)` }).from(partners);
    const totalVehicles = await db.select({ count: sql<number>`count(*)` }).from(vehicles);
    const totalBookings = await db.select({ count: sql<number>`count(*)` }).from(bookings);
    const pendingPartners = await db.select({ count: sql<number>`count(*)` }).from(partners).where(eq(partners.status, "pending"));
    const pendingBookings = await db.select({ count: sql<number>`count(*)` }).from(bookings).where(eq(bookings.status, "pending"));

    return {
      totalCustomers: totalCustomers[0].count,
      totalPartners: totalPartners[0].count,
      totalVehicles: totalVehicles[0].count,
      totalBookings: totalBookings[0].count,
      pendingPartners: pendingPartners[0].count,
      pendingBookings: pendingBookings[0].count,
    };
  }


}

export const storage = new DatabaseStorage();