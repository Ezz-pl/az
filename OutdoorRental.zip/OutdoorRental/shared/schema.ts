import { pgTable, text, serial, integer, boolean, decimal, timestamp, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// نظام الإدارة الرئيسي - المدراء
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("admin"), // admin, super_admin
  isActive: boolean("is_active").notNull().default(true),
  permissions: jsonb("permissions").default(sql`'{"manage_users": true, "manage_partners": true, "manage_content": true, "manage_bookings": true}'::jsonb`),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// العملاء المسجلين
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: varchar("phone", { length: 20 }).notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  isVerified: boolean("is_verified").default(false),
  verificationCode: varchar("verification_code", { length: 6}),
  resetPasswordCode: varchar("reset_password_code", { length: 6}),
  isActive: boolean("is_active").default(true),
  address: text("address"),
  city: text("city"),
  region: text("region"),
  nationalId: varchar("national_id", { length: 20}),
  dateOfBirth: timestamp("date_of_birth"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// الشركاء/المضيفين
export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  email: varchar("email", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }),
  contactName: text("contact_name"),
  phone: varchar("phone", { length: 20 }).notNull(),
  commercialLicense: varchar("commercial_license", { length: 50 }),
  taxNumber: varchar("tax_number", { length: 50 }),
  status: text("status").default("pending"), // pending, approved, rejected, suspended
  rejectionReason: text("rejection_reason"),
  approvedAt: timestamp("approved_at"),
  approvedBy: integer("approved_by").references(() => admins.id),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// المناطق
export const regions = pgTable("regions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  slug: varchar("slug", { length: 50 }).notNull().unique(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// تصنيفات المركبات والخدمات
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  slug: varchar("slug", { length: 50 }).notNull().unique(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  icon: text("icon").notNull(),
  color: varchar("color", { length: 7 }).default("#3B82F6"),
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// المركبات والخدمات
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull().references(() => partners.id),
  categoryId: integer("category_id").notNull().references(() => categories.id),
  regionId: integer("region_id").notNull().references(() => regions.id),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  pricePerDay: decimal("price_per_day", { precision: 10, scale: 2 }).notNull(),
  pricePerHour: decimal("price_per_hour", { precision: 10, scale: 2 }),
  images: jsonb("images").default(sql`'[]'::jsonb`),
  features: jsonb("features").default(sql`'[]'::jsonb`),
  featuresAr: jsonb("features_ar").default(sql`'[]'::jsonb`),
  capacity: integer("capacity").notNull(),
  minAge: integer("min_age").default(18),
  requiresLicense: boolean("requires_license").default(false),
  licenseType: text("license_type"),
  location: text("location").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  isActive: boolean("is_active").default(true),
  isApproved: boolean("is_approved").default(false),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0.00"),
  totalReviews: integer("total_reviews").default(0),
  viewCount: integer("view_count").default(0),
  bookingCount: integer("booking_count").default(0),
  approvedAt: timestamp("approved_at"),
  approvedBy: integer("approved_by").references(() => admins.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// الحجوزات
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  bookingNumber: varchar("booking_number", { length: 20 }).notNull().unique(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id),
  partnerId: integer("partner_id").notNull().references(() => partners.id),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalDays: integer("total_days").notNull(),
  pricePerDay: decimal("price_per_day", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  status: text("status").default("pending"), // pending, confirmed, cancelled, completed
  paymentStatus: text("payment_status").default("pending"), // pending, paid, refunded
  paymentMethod: text("payment_method"),
  transactionId: text("transaction_id"),
  notes: text("notes"),
  customerNotes: text("customer_notes"),
  partnerNotes: text("partner_notes"),
  cancellationReason: text("cancellation_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  confirmedAt: timestamp("confirmed_at"),
  cancelledAt: timestamp("cancelled_at"),
});

// المراجعات والتقييمات
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").notNull().references(() => bookings.id),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id),
  partnerId: integer("partner_id").notNull().references(() => partners.id),
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  images: jsonb("images").default(sql`'[]'::jsonb`),
  isVisible: boolean("is_visible").default(true),
  partnerResponse: text("partner_response"),
  partnerResponseAt: timestamp("partner_response_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// المحتوى القابل للتحرير
export const content = pgTable("content", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  title: text("title"),
  titleAr: text("title_ar"),
  content: text("content"),
  contentAr: text("content_ar"),
  type: text("type").default("text"), // text, html, json
  isActive: boolean("is_active").default(true),
  updatedBy: integer("updated_by").references(() => admins.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// الإعدادات العامة
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  type: text("type").default("text"), // text, number, boolean, json
  description: text("description"),
  updatedBy: integer("updated_by").references(() => admins.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// أنواع العملات والدفع
export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  type: text("type").notNull(), // credit_card, bank_transfer, cash, digital_wallet
  isActive: boolean("is_active").default(true),
  fees: decimal("fees", { precision: 5, scale: 2 }).default("0.00"),
  configuration: jsonb("configuration"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod Schemas
export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
  verificationCode: true,
  resetPasswordCode: true,
  isVerified: true,
  isActive: true,
});

export const insertPartnerSchema = createInsertSchema(partners).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  approvedAt: true,
  approvedBy: true,
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
  isApproved: true,
  rating: true,
  totalReviews: true,
  viewCount: true,
  bookingCount: true,
  approvedAt: true,
  approvedBy: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  bookingNumber: true,
  createdAt: true,
  confirmedAt: true,
  cancelledAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
  partnerResponseAt: true,
});

// Types
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Partner = typeof partners.$inferSelect;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type Region = typeof regions.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Content = typeof content.$inferSelect;
export type Setting = typeof settings.$inferSelect;
export type PaymentMethod = typeof paymentMethods.$inferSelect;

// سجل البحث والتصفح
export const searchHistory = pgTable("search_history", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull(),
  customerId: integer("customer_id").references(() => customers.id),
  searchQuery: text("search_query"),
  categoryId: integer("category_id").references(() => categories.id),
  regionId: integer("region_id").references(() => regions.id),
  priceRange: jsonb("price_range"),
  filters: jsonb("filters"),
  resultsCount: integer("results_count").default(0),
  clickedVehicleIds: jsonb("clicked_vehicle_ids").default(sql`'[]'::jsonb`),
  userAgent: text("user_agent"),
  ipAddress: varchar("ip_address", { length: 45 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// تفاعل المستخدم مع المركبات
export const userInteractions = pgTable("user_interactions", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull(),
  customerId: integer("customer_id").references(() => customers.id),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id),
  interactionType: varchar("interaction_type", { length: 50 }).notNull(),
  duration: integer("duration"),
  source: varchar("source", { length: 100 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// التوصيات المخصصة
export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull(),
  customerId: integer("customer_id").references(() => customers.id),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id),
  recommendationType: varchar("recommendation_type", { length: 50 }).notNull(),
  score: decimal("score", { precision: 5, scale: 4 }).notNull(),
  reason: text("reason"),
  shown: boolean("shown").default(false),
  clicked: boolean("clicked").default(false),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

// أنواع جديدة للتوصيات
export type SearchHistory = typeof searchHistory.$inferSelect;
export type UserInteraction = typeof userInteractions.$inferSelect;
export type Recommendation = typeof recommendations.$inferSelect;