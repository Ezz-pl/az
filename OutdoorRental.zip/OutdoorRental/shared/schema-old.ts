import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  category: text("category").notNull(), // "desert_camping", "marine_trips", "atv_adventures"
  categoryAr: text("category_ar").notNull(),
  subcategory: text("subcategory"), // "with_car", "sessions_only", "tents_only", "boats", "jetski", "atv_quad", "atv_racing"
  subcategoryAr: text("subcategory_ar"),
  pricePerDay: decimal("price_per_day", { precision: 10, scale: 2 }).notNull(),
  imageUrl: text("image_url").notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).notNull(),
  available: boolean("available").notNull().default(true),
  features: text("features").array(),
  featuresAr: text("features_ar").array(),
  location: text("location").notNull(),
  locationAr: text("location_ar").notNull(),
  capacity: integer("capacity").notNull(),
  region: text("region").notNull(), // "hail", "eastern_coast", "red_sea", etc.
  regionAr: text("region_ar").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerEmail: text("customer_email").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // "pending", "confirmed", "cancelled"
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  icon: text("icon").notNull(),
  slug: text("slug").notNull().unique(),
  vehicleCount: integer("vehicle_count").notNull().default(0),
  bgImage: text("bg_image"),
  color: text("color").notNull().default("#168b52"),
});

// جدول الشركاء/المضيفين
export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  businessType: text("business_type").notNull(),
  businessTypeAr: text("business_type_ar").notNull(),
  description: text("description").notNull(),
  features: text("features").notNull(),
  regionId: text("region_id").notNull(),
  categoryId: integer("category_id").notNull(),
  vehicleName: text("vehicle_name").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  images: text("images").array().notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  loginCode: text("login_code"), // كود تسجيل الدخول
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  approvedBy: text("approved_by"),
  rejectionReason: text("rejection_reason"),
});

// جدول المستخدمين العاديين
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  password: text("password").notNull(),
  verificationCode: text("verification_code"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  region: text("region").notNull(),
  regionAr: text("region_ar").notNull(),
  type: text("type").notNull(), // mountain, historical, natural, reservoir
  typeAr: text("type_ar").notNull(),
  imageUrl: text("image_url"),
  coordinates: text("coordinates"),
  features: text("features").array(),
  featuresAr: text("features_ar").array(),
  difficulty: text("difficulty"), // easy, moderate, challenging
  difficultyAr: text("difficulty_ar"),
  bestTimeToVisit: text("best_time_to_visit"),
  bestTimeToVisitAr: text("best_time_to_visit_ar"),
  nearbyServices: text("nearby_services").array(),
  nearbyServicesAr: text("nearby_services_ar").array(),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0.0"),
  popular: boolean("popular").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
  status: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true,
  createdAt: true,
});

export const insertPartnerSchema = createInsertSchema(partners).omit({
  id: true,
  createdAt: true,
  approvedAt: true,
  status: true,
  loginCode: true,
  isActive: true,
  approvedBy: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  verificationCode: true,
  isVerified: true,
});

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;
export type InsertDestination = z.infer<typeof insertDestinationSchema>;
export type Destination = typeof destinations.$inferSelect;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type Partner = typeof partners.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Regions table
export const regions = pgTable("regions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  imageUrl: text("image_url"),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Partners/Hosts table
export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  regionId: integer("region_id").notNull(),
  businessType: text("business_type").notNull(), // "vehicle_rental", "catering", "cooking"
  businessTypeAr: text("business_type_ar").notNull(),
  status: text("status").notNull().default("pending"), // "pending", "approved", "rejected", "suspended"
  rating: decimal("rating", { precision: 3, scale: 1 }).default("0.0"),
  totalBookings: integer("total_bookings").default(0),
  joinedAt: timestamp("joined_at").defaultNow(),
  approvedAt: timestamp("approved_at"),
  profileImage: text("profile_image"),
  businessLicense: text("business_license"),
  bankAccount: text("bank_account"),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }).default("15.00"),
});

// Admin Users table
export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("staff"), // "super_admin", "admin", "manager", "staff"
  permissions: text("permissions").array(), // ["users", "bookings", "vehicles", "partners", "analytics"]
  active: boolean("active").default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by"),
});

// Updated vehicles to reference partner
export const vehiclesWithPartner = pgTable("vehicles_new", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  category: text("category").notNull(),
  categoryAr: text("category_ar").notNull(),
  subcategory: text("subcategory"),
  subcategoryAr: text("subcategory_ar"),
  pricePerDay: decimal("price_per_day", { precision: 10, scale: 2 }).notNull(),
  imageUrl: text("image_url").notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).notNull(),
  available: boolean("available").notNull().default(true),
  features: text("features").array(),
  featuresAr: text("features_ar").array(),
  location: text("location").notNull(),
  locationAr: text("location_ar").notNull(),
  capacity: integer("capacity").notNull(),
  regionId: integer("region_id").notNull(),
  partnerId: integer("partner_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Catering services
export const cateringServices = pgTable("catering_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  category: text("category").notNull(), // "coffee_services", "desserts", "general_catering"
  categoryAr: text("category_ar").notNull(),
  pricePerPerson: decimal("price_per_person", { precision: 10, scale: 2 }),
  minimumOrder: integer("minimum_order").default(10),
  imageUrl: text("image_url").notNull(),
  partnerId: integer("partner_id").notNull(),
  regionId: integer("region_id").notNull(),
  available: boolean("available").default(true),
  features: text("features").array(),
  featuresAr: text("features_ar").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cooking services
export const cookingServices = pgTable("cooking_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  category: text("category").notNull(), // "maftool", "sweets", "grilling_chef"
  categoryAr: text("category_ar").notNull(),
  pricePerService: decimal("price_per_service", { precision: 10, scale: 2 }),
  imageUrl: text("image_url").notNull(),
  partnerId: integer("partner_id").notNull(),
  regionId: integer("region_id").notNull(),
  available: boolean("available").default(true),
  includes: text("includes").array(), // What's included in the service
  includesAr: text("includes_ar").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Enhanced bookings
export const enhancedBookings = pgTable("bookings_new", {
  id: serial("id").primaryKey(),
  serviceType: text("service_type").notNull(), // "vehicle", "catering", "cooking"
  serviceId: integer("service_id").notNull(),
  partnerId: integer("partner_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerEmail: text("customer_email").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  commissionAmount: decimal("commission_amount", { precision: 10, scale: 2 }),
  paymentMethod: text("payment_method"), // "tabby", "tamara", "apple_pay", "mada", "visa"
  paymentStatus: text("payment_status").default("pending"), // "pending", "paid", "refunded"
  status: text("status").notNull().default("pending"), // "pending", "confirmed", "cancelled", "completed"
  notes: text("notes"),
  guestCount: integer("guest_count"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertRegionSchema = createInsertSchema(regions).omit({ id: true, createdAt: true });
export const insertPartnerSchema = createInsertSchema(partners).omit({ id: true, joinedAt: true, approvedAt: true });
export const insertAdminUserSchema = createInsertSchema(adminUsers).omit({ id: true, createdAt: true, lastLogin: true });
export const insertCateringServiceSchema = createInsertSchema(cateringServices).omit({ id: true, createdAt: true });
export const insertCookingServiceSchema = createInsertSchema(cookingServices).omit({ id: true, createdAt: true });

// Reviews and Ratings System
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  serviceType: text("service_type").notNull(), // "vehicle", "catering", "cooking", "partner"
  serviceId: integer("service_id").notNull(),
  partnerId: integer("partner_id"),
  bookingId: integer("booking_id"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull(), // 1.0 to 5.0
  title: text("title"),
  titleAr: text("title_ar"),
  comment: text("comment"),
  commentAr: text("comment_ar"),
  pros: text("pros").array(), // What they liked
  prosAr: text("pros_ar").array(),
  cons: text("cons").array(), // What could be improved
  consAr: text("cons_ar").array(),
  images: text("images").array(), // Review photos
  verified: boolean("verified").default(false), // From actual booking
  helpful: integer("helpful").default(0), // Helpful votes
  status: text("status").default("pending"), // "pending", "approved", "rejected"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Location and Maps System
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description"),
  descriptionAr: text("description_ar"),
  address: text("address").notNull(),
  addressAr: text("address_ar").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  regionId: integer("region_id").notNull(),
  type: text("type").notNull(), // "pickup_point", "destination", "service_area"
  serviceTypes: text("service_types").array(), // ["vehicle", "catering", "cooking"]
  amenities: text("amenities").array(), // ["parking", "restrooms", "fuel_station", "restaurant"]
  amenitiesAr: text("amenities_ar").array(),
  accessible: boolean("accessible").default(true),
  workingHours: text("working_hours"), // JSON string with opening hours
  contactPhone: text("contact_phone"),
  images: text("images").array(),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Vehicle Locations (linking vehicles to specific pickup/drop-off points)
export const vehicleLocations = pgTable("vehicle_locations", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull(),
  locationId: integer("location_id").notNull(),
  isPickupPoint: boolean("is_pickup_point").default(true),
  isDropoffPoint: boolean("is_dropoff_point").default(true),
  additionalFee: decimal("additional_fee", { precision: 8, scale: 2 }).default("0.00"),
  instructions: text("instructions"), // Special pickup/dropoff instructions
  instructionsAr: text("instructions_ar"),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Service Areas (for delivery services like catering)
export const serviceAreas = pgTable("service_areas", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  regionId: integer("region_id").notNull(),
  coordinates: text("coordinates").notNull(), // GeoJSON polygon
  deliveryFee: decimal("delivery_fee", { precision: 8, scale: 2 }).default("0.00"),
  minimumOrder: decimal("minimum_order", { precision: 8, scale: 2 }),
  maxDeliveryTime: integer("max_delivery_time"), // in minutes
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Review Responses (Partner responses to reviews)
export const reviewResponses = pgTable("review_responses", {
  id: serial("id").primaryKey(),
  reviewId: integer("review_id").notNull(),
  partnerId: integer("partner_id").notNull(),
  response: text("response").notNull(),
  responseAr: text("response_ar"),
  respondedBy: text("responded_by"), // Partner name or staff name
  createdAt: timestamp("created_at").defaultNow(),
});

// Review Statistics (cached for performance)
export const reviewStats = pgTable("review_stats", {
  id: serial("id").primaryKey(),
  serviceType: text("service_type").notNull(),
  serviceId: integer("service_id").notNull(),
  totalReviews: integer("total_reviews").default(0),
  averageRating: decimal("average_rating", { precision: 3, scale: 2 }).default("0.00"),
  ratingDistribution: text("rating_distribution"), // JSON: {"5": 10, "4": 5, "3": 2, "2": 1, "1": 0}
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Insert schemas for new tables
export const insertReviewSchema = createInsertSchema(reviews).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true, 
  helpful: true, 
  status: true 
});

export const insertLocationSchema = createInsertSchema(locations).omit({ 
  id: true, 
  createdAt: true, 
  verified: true 
});

export const insertVehicleLocationSchema = createInsertSchema(vehicleLocations).omit({ 
  id: true, 
  createdAt: true 
});

export const insertServiceAreaSchema = createInsertSchema(serviceAreas).omit({ 
  id: true, 
  createdAt: true 
});

export const insertReviewResponseSchema = createInsertSchema(reviewResponses).omit({ 
  id: true, 
  createdAt: true 
});

// Types
export type Region = typeof regions.$inferSelect;
export type InsertRegion = z.infer<typeof insertRegionSchema>;
export type Partner = typeof partners.$inferSelect;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type AdminUser = typeof adminUsers.$inferSelect;
export type InsertAdminUser = z.infer<typeof insertAdminUserSchema>;
export type CateringService = typeof cateringServices.$inferSelect;
export type InsertCateringService = z.infer<typeof insertCateringServiceSchema>;
export type CookingService = typeof cookingServices.$inferSelect;
export type InsertCookingService = z.infer<typeof insertCookingServiceSchema>;

// New types
export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Location = typeof locations.$inferSelect;
export type InsertLocation = z.infer<typeof insertLocationSchema>;
export type VehicleLocation = typeof vehicleLocations.$inferSelect;
export type InsertVehicleLocation = z.infer<typeof insertVehicleLocationSchema>;
export type ServiceArea = typeof serviceAreas.$inferSelect;
export type InsertServiceArea = z.infer<typeof insertServiceAreaSchema>;
export type ReviewResponse = typeof reviewResponses.$inferSelect;
export type InsertReviewResponse = z.infer<typeof insertReviewResponseSchema>;
export type ReviewStats = typeof reviewStats.$inferSelect;
