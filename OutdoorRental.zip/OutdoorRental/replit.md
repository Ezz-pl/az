# Vehicle Rental Platform

## Overview

This is a full-stack vehicle rental application built with React, Express, and Drizzle ORM. The platform allows users to browse, search, and book various types of recreational vehicles including off-road vehicles, boats, jet skis, and ATVs. The application features a bilingual interface (Arabic/English) and is designed for adventure and recreational vehicle rentals.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui components
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Uses connect-pg-simple for PostgreSQL session storage
- **Development**: Hot module replacement via Vite integration

### Key Design Decisions
1. **Monorepo Structure**: Organized as client/server/shared folders for better code organization
2. **TypeScript Throughout**: Ensures type safety across the entire stack
3. **Bilingual Support**: Arabic and English language support built into the data model
4. **Component-Based UI**: Reusable components with shadcn/ui design system
5. **Responsive Design**: Mobile-first approach with Tailwind CSS

## Key Components

### Database Schema
- **Vehicles**: Core entity with multilingual support (Arabic/English names and descriptions)
- **Bookings**: Customer reservation system with status tracking
- **Categories**: Vehicle categorization with icons and descriptions
- **User Management**: Basic user authentication structure

### API Endpoints
- `GET /api/vehicles` - List all vehicles with optional search and category filtering
- `GET /api/vehicles/:id` - Get specific vehicle details
- `GET /api/vehicles/category/:category` - Filter vehicles by category
- `POST /api/bookings` - Create new booking reservation
- `GET /api/categories` - List all vehicle categories

### Frontend Pages
- **Home**: Hero section with search, featured vehicles, and categories
- **Vehicles**: Browse all vehicles with filtering and search
- **Vehicle Detail**: Detailed view with booking functionality
- **Booking Modal**: Interactive booking form with validation

## Data Flow

1. **User Interaction**: User searches/filters vehicles through the frontend
2. **API Requests**: Frontend makes HTTP requests to Express backend
3. **Database Queries**: Backend queries PostgreSQL via Drizzle ORM
4. **Response Processing**: Data is transformed and returned to frontend
5. **State Management**: TanStack Query manages caching and synchronization
6. **UI Updates**: React components re-render with updated data

## External Dependencies

### Production Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: drizzle-orm and drizzle-zod for database operations
- **UI Components**: Extensive Radix UI component library
- **Forms**: React Hook Form with Zod validation
- **Dates**: date-fns for date manipulation
- **Styling**: Tailwind CSS with class-variance-authority

### Development Tools
- **Build**: Vite with React plugin
- **Database**: Drizzle Kit for migrations and schema management
- **TypeScript**: Full TypeScript configuration
- **Linting**: ESBuild for production bundling

## Deployment Strategy

### Development
- Uses Vite dev server with hot module replacement
- Integrated Express server for API development
- Database migrations via Drizzle Kit
- Environment-based configuration

### Production
1. **Build Process**: 
   - Frontend: Vite builds React app to `dist/public`
   - Backend: ESBuild bundles server code to `dist/index.js`
2. **Deployment**: 
   - Single Node.js process serves both static files and API
   - PostgreSQL database (configured for Neon serverless)
   - Environment variables for database connection

### Database Management
- **Migrations**: Managed through Drizzle Kit
- **Schema**: Centralized in `shared/schema.ts`
- **Connection**: Configured for PostgreSQL with connection pooling

## Changelog

- January 09, 2025: Complete website cleanup and production preparation
  - Removed all test data, dummy vehicles, and fake statistics
  - Created clean database schema with only basic categories
  - Updated all text content to remove specific locations and fake numbers
  - Prepared empty state messages directing users to partner registration
  - Fixed navigation and routing errors for production readiness

- July 07, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.
Priority: No test data or fake content - only real partner submissions should appear.